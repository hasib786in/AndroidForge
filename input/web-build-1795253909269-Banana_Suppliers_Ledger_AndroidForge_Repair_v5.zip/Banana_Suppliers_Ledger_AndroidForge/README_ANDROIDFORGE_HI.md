# 🍌Suppliers Ledger — AndroidForge Project

यह ZIP एक Android Studio / AndroidForge-importable Android Gradle project है। यह आपके दिए हुए HTML ledger को Android WebView में चलाता है। यह ZIP स्वयं APK नहीं है; APK AndroidForge या GitHub Actions में build होगा।

## पहले से सेट की गई बातें
- Installed app / launcher label: **🍌Suppliers Ledger** (इमोजी, spelling और capitalization सहित)
- Launcher icon: उपयोगकर्ता द्वारा दिया गया `launcher-icon-original.png`
- Android adaptive launcher icon तथा mdpi, hdpi, xhdpi, xxhdpi और xxxhdpi legacy icon resources
- मूल HTML को `app/src/main/assets/index.html` में रखा गया है
- WebView JavaScript और DOM storage चालू हैं ताकि HTML app का localStorage डेटा डिवाइस पर बना रहे
- WhatsApp / SMS / फोन / बाहरी वेब लिंक Android के उपयुक्त ऐप में खोले जाते हैं
- HTML file input, जैसे JSON/CSV/Excel restore, Android file picker से जुड़ा है
- HTML `window.print()` को Android Print Framework से जोड़ा गया है
- GitHub Actions workflow APK build करके artifact upload करता है

## AndroidForge / GitHub build
1. ZIP को extract करें।
2. पूरा project root AndroidForge में import करें या GitHub repository के root में upload करें।
3. GitHub में **Actions → Build Banana Suppliers Ledger APK → Run workflow** चुनें; अथवा `main` / `master` branch पर push करें।
4. सफल build के बाद workflow run के **Artifacts** भाग से `Banana-Suppliers-Ledger-debug-apk` डाउनलोड करें।
5. APK को Samsung फोन में install करें।

## Project build configuration
- Application ID: `com.bananasuppliers.ledger`
- Minimum Android: API 23 (Android 6.0)
- Compile / Target SDK: 35
- Java: 17
- Android Gradle Plugin: 8.7.3
- Gradle: 8.9

## महत्वपूर्ण व्यवहार
- Excel import/export के लिए HTML में SheetJS CDN script है; Excel सुविधा लोड करने के लिए इंटरनेट कनेक्शन चाहिए।
- HTML ledger records browser `localStorage` में सेव होते हैं। ऐप uninstall या app data clear करने से पहले HTML के Backup tab से JSON backup export कर लें।
- यह project debug APK बनाता है। Play Store / production distribution के लिए release signing configuration अलग से درکار होगी।


## Android 12–16 compatibility update (v3)

- `compileSdk` और `targetSdk` अब 36 (Android 16) हैं।
- Android Gradle Plugin 8.10.1 और CI Gradle 8.11.1 पर अपडेट किया गया है।
- `minSdk 23` बरकरार है; Android 12–16 के लिए अलग-अलग APK की जरूरत नहीं है।
- Android 15/16 edge-to-edge के लिए system-bar insets WebView padding में लागू किए गए हैं।
- Android 13+ के लिए `OnBackInvokedCallback` जोड़ा गया है; Android 12 और उससे पुराने संस्करणों के लिए legacy back handling बरकरार है।
- प्रोजेक्ट में कोई `.so`/NDK native library शामिल नहीं है; इसलिए इस source project में ABI-specific native payload नहीं है और 16 KB page-size native alignment का अलग native rebuild लागू नहीं होता।

**महत्वपूर्ण QA सीमा:** इस ZIP में source/configuration बदलाव किए गए हैं और archive/syntax checks किए जा सकते हैं, लेकिन वास्तविक APK build, Android 12/13/14/15/16 emulator/device run, 32-bit/64-bit installation और print output test अभी AndroidForge/GitHub Actions या वास्तविक उपकरणों पर करना बाकी है। इसलिए इसे verified device certification न समझें।


## Universal Android / OEM compatibility (v4)

यह ऐप किसी Samsung-only API या brand-specific service पर निर्भर नहीं है। यह Android Activity, Android WebView, Android Print Framework, DownloadManager और standard intents उपयोग करता है। इसलिए इसका एक ही APK Android 12–16 वाले Vivo, OPPO, Redmi/Xiaomi, realme, Motorola, OnePlus, Samsung तथा अन्य Android ब्रांडों के लिए बनाया गया है।

- `minSdk 23`, `compileSdk 36`, `targetSdk 36`; AGP 8.10.1 और Gradle 8.11.1.
- कोई ABI split/`abiFilters` नहीं; कोई `.so` native library नहीं। इस Java/WebView project के लिए एक universal APK configuration है।
- अलग-अलग OEM के status/navigation bar, display cutout और keyboard insets को संभालने के लिए edge-to-edge insets लागू किए गए हैं।
- File chooser cancel/result और PrintManager null-service स्थितियों को संभाला गया है।
- App version 1.1.0 / versionCode 2 किया गया है ताकि पहले version 1.0.0 के ऊपर update install किया जा सके।
- GitHub Actions `lintDebug` और `assembleDebug` चलाता है।

**Compatibility की सीमा:** Android संस्करण/API compatibility और OEM brand compatibility source-level पर तैयार की गई है। हर ब्रांड के हर model/ROM पर वास्तविक प्रमाणन नहीं हुआ है। OEM battery/background restrictions, default browser/WhatsApp, installed Android System WebView provider, printer service और firmware variations अलग हो सकते हैं। अंतिम पुष्टि के लिए वास्तविक फोन पर install, open, data save/reopen, file picker, download, WhatsApp, PDF print और app update का परीक्षण करें।

### फोन परीक्षण सूची
- [ ] Vivo (Funtouch OS)
- [ ] OPPO (ColorOS)
- [ ] Redmi/Xiaomi (MIUI/HyperOS)
- [ ] realme (realme UI)
- [ ] Samsung (One UI)
- [ ] Motorola / OnePlus या अन्य Android
- [ ] Android 12, 13, 14, 15, 16 पर install और basic workflow
- [ ] 32-bit तथा 64-bit APK install/runtime, जहाँ device उपलब्ध हो


## Build reliability repair (v5)

- Gradle Wrapper configuration is now explicitly pinned to Gradle **8.11.1**, the minimum compatible Gradle line for Android Gradle Plugin **8.10.1**. This avoids falling back to an older preinstalled Gradle when AndroidForge imports a project without a wrapper configuration.
- The AndroidForge/CI build path now installs Android SDK **platforms;android-36** and **build-tools;36.0.0** before building.
- APK assembly (`assembleDebug`) is the blocking build step. Lint runs separately and its report is uploaded without preventing a valid APK from being produced.
- The repository GitHub Actions workflow uploads both the APK and diagnostic reports.

**Wrapper JAR note:** This archive includes wrapper scripts and the pinned wrapper properties, but not the binary `gradle-wrapper.jar`. AndroidForge documents that it can regenerate a missing wrapper JAR. If building outside AndroidForge, run `gradle wrapper --gradle-version 8.11.1 --distribution-type bin` once using installed Gradle 8.11.1, then use `./gradlew`.

**Verification boundary:** ZIP integrity, project structure, XML/YAML text configuration, and key app identity settings were checked here. A real Android APK build and physical-device QA were not run in this environment. The screenshot does not expose the full failing Gradle log, so the precise original failing task cannot be confirmed from the screenshot alone.
