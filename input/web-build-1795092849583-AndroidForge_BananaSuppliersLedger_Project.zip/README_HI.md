# Banana Suppliers Ledger — Android app project

इंस्टॉल होने के बाद ऐप का नाम `🍌Suppliers Ledger` दिखाई देगा। यह Android Studio प्रोजेक्ट आपके मौजूदा `Banana Suppliers Ledger` HTML ऐप को Android WebView ऐप के रूप में पैक करता है। HTML ऐप `app/src/main/assets/index.html` में शामिल है।

## APK बनाने के लिए
1. Android Studio इंस्टॉल करें (Android Studio का वर्तमान stable संस्करण)।
2. इस ZIP को Extract करें।
3. Android Studio → **Open** → Extract किए गए `BananaSuppliersLedgerAndroid` फ़ोल्डर को चुनें।
4. Gradle Sync पूरा होने दें और Android SDK Platform 35 इंस्टॉल करें, यदि पूछा जाए।
5. **Build → Build Bundle(s) / APK(s) → Build APK(s)** चुनें।
6. APK सामान्यतः `app/build/outputs/apk/debug/app-debug.apk` में बनेगा।

## शामिल Android व्यवहार
- WebView में मौजूदा HTML ledger और JavaScript चलेंगे।
- WebView DOM storage चालू है; ऐप का `localStorage` डेटा उसी ऐप इंस्टॉलेशन में बना रहता है।
- Crates Ledger और Financial Ledger के print actions Android के native Print Framework को भेजे जाते हैं; Print स्क्रीन में **Save as PDF** चुनें।
- WhatsApp और SMS लिंक संबंधित Android ऐप में खुलते हैं।
- JSON/Excel import के लिए Android file picker उपलब्ध है।
- XLSX लाइब्रेरी jsDelivr CDN से लोड होती है, इसलिए Excel सुविधाओं के लिए इंटरनेट चाहिए।

## महत्वपूर्ण सीमाएँ
- यह Android Studio source project है, पहले से compiled/sign किया हुआ APK नहीं। इस वातावरण में Android SDK/Gradle build tool उपलब्ध नहीं था, इसलिए APK binary यहाँ compile नहीं की गई।
- ऐप का डेटा Android app के निजी storage में है। ऐप uninstall या app data clear करने पर local data मिट सकता है। नियमित JSON backup रखें।
- Debug APK केवल परीक्षण/सीधे इंस्टॉल के लिए है। Play Store या व्यापक वितरण के लिए अपना release signing key बनाकर signed release APK/AAB तैयार करें।

## ऐप आइकन
- आपके दिए हुए Banana Suppliers Ledger चित्र को Android launcher icon के रूप में जोड़ा गया है।
- पुराने Android launchers के लिए mdpi से xxxhdpi तक PNG icons और नए Android के लिए adaptive/round icons शामिल हैं।
- APK इंस्टॉल होने के बाद फोन के App Drawer और Home Screen पर यही आइकन दिखेगा (launcher की mask/shape के अनुसार)।
