package com.hasibkhan.bananasuppliersledger

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.print.PrintAttributes
import android.print.PrintManager
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import android.view.ViewGroup

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private var fileCallback: ValueCallback<Array<Uri>>? = null
    private var printSequence = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        webView = WebView(this)
        webView.layoutParams = ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        )
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.allowFileAccess = true
        webView.settings.allowContentAccess = true
        webView.settings.javaScriptCanOpenWindowsAutomatically = true
        webView.settings.setSupportMultipleWindows(false)
        webView.addJavascriptInterface(AndroidPrintBridge(), "AndroidPrint")
        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                return handleExternalUrl(request.url)
            }
            @Suppress("DEPRECATION")
            override fun shouldOverrideUrlLoading(view: WebView, url: String): Boolean {
                return handleExternalUrl(Uri.parse(url))
            }
        }
        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                view: WebView,
                callback: ValueCallback<Array<Uri>>,
                params: FileChooserParams
            ): Boolean {
                fileCallback?.onReceiveValue(null)
                fileCallback = callback
                val intent = params.createIntent().apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                }
                return try {
                    startActivityForResult(intent, FILE_REQUEST)
                    true
                } catch (e: ActivityNotFoundException) {
                    fileCallback = null
                    Toast.makeText(this@MainActivity, "फाइल चुनने वाला ऐप उपलब्ध नहीं है।", Toast.LENGTH_LONG).show()
                    false
                }
            }
        }
        setContentView(webView)
        if (savedInstanceState == null) {
            webView.loadUrl("file:///android_asset/index.html")
        } else {
            webView.restoreState(savedInstanceState)
        }

        // Back navigates inside the ledger first; otherwise it exits the app.
    }

    private fun handleExternalUrl(uri: Uri): Boolean {
        val scheme = uri.scheme?.lowercase() ?: return false
        if (scheme == "file" || scheme == "about" || scheme == "data" || scheme == "https" && uri.host == "cdn.jsdelivr.net") return false
        if (scheme == "https" && (uri.host == "wa.me" || uri.host == "api.whatsapp.com")) {
            return try {
                startActivity(Intent(Intent.ACTION_VIEW, uri).setPackage("com.whatsapp"))
                true
            } catch (e: ActivityNotFoundException) {
                openExternal(Intent(Intent.ACTION_VIEW, uri))
            }
        }
        if (scheme == "sms" || scheme == "smsto") {
            return openExternal(Intent(Intent.ACTION_SENDTO, uri))
        }
        if (scheme == "tel") return openExternal(Intent(Intent.ACTION_DIAL, uri))
        if (scheme == "mailto") return openExternal(Intent(Intent.ACTION_SENDTO, uri))
        if (scheme == "http" || scheme == "https") return openExternal(Intent(Intent.ACTION_VIEW, uri))
        return openExternal(Intent(Intent.ACTION_VIEW, uri))
    }

    private fun openExternal(intent: Intent): Boolean {
        return try {
            startActivity(intent)
            true
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(this, "इस लिंक के लिए कोई उपयुक्त ऐप नहीं मिला।", Toast.LENGTH_LONG).show()
            true
        }
    }

    inner class AndroidPrintBridge {
        @JavascriptInterface
        fun printHtml(html: String) {
            runOnUiThread {
                val printWebView = WebView(this@MainActivity)
                printWebView.settings.javaScriptEnabled = true
                printWebView.loadDataWithBaseURL("file:///android_asset/", html, "text/html", "UTF-8", null)
                printWebView.webViewClient = object : WebViewClient() {
                    override fun onPageFinished(view: WebView, url: String) {
                        try {
                            val manager = getSystemService(PRINT_SERVICE) as PrintManager
                            val adapter = view.createPrintDocumentAdapter("Banana-Ledger-${++printSequence}")
                            manager.print(
                                "Banana Suppliers Ledger",
                                adapter,
                                PrintAttributes.Builder()
                                    .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                                    .setResolution(PrintAttributes.Resolution("pdf", "PDF", 300, 300))
                                    .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                                    .build()
                            )
                            webView.evaluateJavascript("window.__cleanupAndroidPrint && window.__cleanupAndroidPrint()", null)
                        } catch (e: Exception) {
                            Toast.makeText(this@MainActivity, "PDF प्रिंट शुरू नहीं हो सका: ${e.message}", Toast.LENGTH_LONG).show()
                        }
                    }
                }
            }
        }
    }

    @Deprecated("Deprecated by Android, retained for WebView file picker compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == FILE_REQUEST) {
            val result = if (resultCode == RESULT_OK) WebChromeClient.FileChooserParams.parseResult(resultCode, data) else null
            fileCallback?.onReceiveValue(result)
            fileCallback = null
        }
    }

    @Deprecated("Deprecated by Android")
    override fun onBackPressed() {
        if (this::webView.isInitialized && webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        webView.saveState(outState)
        super.onSaveInstanceState(outState)
    }

    override fun onDestroy() {
        fileCallback?.onReceiveValue(null)
        webView.destroy()
        super.onDestroy()
    }

    companion object { private const val FILE_REQUEST = 4201 }
}
