# AndroidForge Upload Package — 🍌Suppliers Ledger

यह ZIP AndroidForge (Professional-X/AndroidForge) के Android source ZIP upload के लिए तैयार है। ZIP खोलने पर project root में `settings.gradle.kts`, `build.gradle.kts` और `app/` मौजूद हैं।

## AndroidForge से APK बनाने के चरण
1. https://professional-x.github.io/AndroidForge/ खोलें।
2. अपने fork किए हुए AndroidForge GitHub repository के owner/repository की जानकारी दें।
3. GitHub Personal Access Token दें जिसमें आवश्यक `repo` और `workflow` permissions हों (या fine-grained token में Contents और Actions access)। Token केवल AndroidForge पेज के browser localStorage में रखा जाता है; इसे किसी chat में साझा न करें।
4. इस ZIP को Upload source ZIP में चुनें।
5. Platform: Android और Build variant: `debug` (पहले परीक्षण के लिए) चुनें।
6. Build दबाएँ और workflow पूरा होने दें।
7. GitHub Actions run से `AndroidForge-APKs` artifact डाउनलोड करें; artifact ZIP के अंदर APK मिलेगा।

## App configuration
- App label: `🍌Suppliers Ledger`
- Application ID: `com.hasibkhan.bananasuppliersledger`
- Min SDK: 23
- Compile / Target SDK: 35
- Android WebView में मौजूदा HTML ledger: `app/src/main/assets/index.html`
- Launcher icon: उपयोगकर्ता द्वारा दिया गया Banana Suppliers Ledger चित्र, विभिन्न density और adaptive icon resources में।

## Notes
- यह source ZIP है, compiled APK नहीं। AndroidForge को इसे build करना होगा।
- Debug build testing/install के लिए है। Release distribution के लिए सुरक्षित release signing key की configuration अलग से करनी होगी।
- ऐप का ledger data app-local storage में रहता है। ऐप uninstall या app data clear करने से पहले JSON backup रखें।
