package com.hasib.cratesledger;

final class AndroidShim {
    private AndroidShim() {}

    static final String SCRIPT =
        "(function(){'use strict';" +
        "if(window.__cratesAndroidShimInstalled)return;" +
        "window.__cratesAndroidShimInstalled=true;" +
        "document.documentElement.classList.add('android-native-app');" +
        "var originalCreate=URL.createObjectURL.bind(URL), blobs=Object.create(null);" +
        "URL.createObjectURL=function(blob){var url=originalCreate(blob);blobs[url]=blob;return url;};" +
        "document.addEventListener('click',function(ev){" +
        "var a=ev.target&&ev.target.closest?ev.target.closest('a[download]'):null;" +
        "if(!a||!a.href||a.href.indexOf('blob:')!==0||!blobs[a.href])return;" +
        "ev.preventDefault();ev.stopImmediatePropagation();" +
        "var url=a.href,blob=blobs[url],name=a.download||'CratesLedger-export';" +
        "var reader=new FileReader();" +
        "reader.onload=function(){" +
        "try{" +
        "if(!window.AndroidLedgerBridge||typeof window.AndroidLedgerBridge.saveBase64File!=='function')" +
        "throw new Error('Android file-save bridge is unavailable');" +
        "window.AndroidLedgerBridge.saveBase64File(name,String(reader.result||''));" +
        "}catch(e){alert('फाइल सेव नहीं हो सकी: '+(e&&e.message?e.message:e));}" +
        "finally{delete blobs[url];}" +
        "};" +
        "reader.onerror=function(){delete blobs[url];alert('डाउनलोड फ़ाइल पढ़ी नहीं जा सकी।');};" +
        "try{reader.readAsDataURL(blob);}catch(e){delete blobs[url];alert('डाउनलोड तैयार नहीं हो सका: '+(e&&e.message?e.message:e));}" +
        "},true);" +
        "window.print=function(){" +
        "try{" +
        "if(!window.AndroidLedgerBridge||typeof window.AndroidLedgerBridge.printHtml!=='function')" +
        "throw new Error('Android print bridge is unavailable');" +
        "window.AndroidLedgerBridge.printHtml(document.documentElement.outerHTML,document.title||'Crates Ledger');" +
        "}catch(e){alert('प्रिंट शुरू नहीं हो सका: '+(e&&e.message?e.message:e));}" +
        "};" +
        "})();";
}
