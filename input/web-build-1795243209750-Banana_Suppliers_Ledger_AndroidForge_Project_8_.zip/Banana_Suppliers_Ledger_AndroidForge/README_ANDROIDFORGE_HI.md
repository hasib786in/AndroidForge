# 🍌Suppliers Ledger — AndroidForge Project

यह ZIP एक Android Studio / AndroidForge-importable Android Gradle project है। यह आपके दिए हुए HTML ledger को Android WebView में चलाता है। यह ZIP स्वयं APK नहीं है; APK AndroidForge या GitHub Actions में build होगा।

## पहले से सेट की गई बातें
- Installed app / launcher label: **🍌Suppliers Ledger** (इमोजी, spelling और capitalization सहित)
- Launcher icon: उपयोगकर्ता द्वारा दिया गया `launcher-icon-original.png`
- Android adaptive launcher icon तथा mdpi, hdpi, xhdpi, xxhdpi और xxxhdpi legacy icon resources
- मूल HTML को `app/src/main/assets/index.html` में रखा गया है
- WebView JavaScript और DOM storage चालू हैं ताकि HTML app का localStorage डेटा डिवाइस पर बना रहे
- WhatsApp / SMS / फोन / बाहरी वेब लिंक Android के उपयुक्त ऐप में खोले जाते हैं
- HTML file input, जैसे JSON/CSV/Excel restore, Android file picker से जुड़ा है
- HTML `window.print()` को Android Print Framework से जोड़ा गया है
- GitHub Actions workflow APK build करके artifact upload करता है

## AndroidForge / GitHub build
1. ZIP को extract करें।
2. पूरा project root AndroidForge में import करें या GitHub repository के root में upload करें।
3. GitHub में **Actions → Build Banana Suppliers Ledger APK → Run workflow** चुनें; अथवा `main` / `master` branch पर push करें।
4. सफल build के बाद workflow run के **Artifacts** भाग से `Banana-Suppliers-Ledger-debug-apk` डाउनलोड करें।
5. APK को Samsung फोन में install करें।

## Project build configuration
- Application ID: `com.bananasuppliers.ledger`
- Minimum Android: API 23 (Android 6.0)
- Compile / Target SDK: 35
- Java: 17
- Android Gradle Plugin: 8.7.3
- Gradle: 8.9

## महत्वपूर्ण व्यवहार
- Excel import/export के लिए HTML में SheetJS CDN script है; Excel सुविधा लोड करने के लिए इंटरनेट कनेक्शन चाहिए।
- HTML ledger records browser `localStorage` में सेव होते हैं। ऐप uninstall या app data clear करने से पहले HTML के Backup tab से JSON backup export कर लें।
- यह project debug APK बनाता है। Play Store / production distribution के लिए release signing configuration अलग से درکار होगी।
