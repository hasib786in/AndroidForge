# Crates Ledger — AndroidForge project (Android 16 API 36)

This project packages the supplied Crates Ledger customer HTML application in
a native Android WebView shell. It retains the customer ledger, localStorage
database, native file picker, JSON/CSV Downloads bridge, bundled SheetJS,
PDF/PrintManager integration, WhatsApp/SMS hand-off, and launcher artwork.

## Build configuration

| Setting | Value |
|---|---|
| Android Gradle Plugin | 8.13.2 |
| Gradle | 8.13 |
| JDK | 17 |
| compileSdk | 36 (Android 16) |
| targetSdk | 36 (Android 16) |
| minSdk | 31 (Android 12) |
| maxSdkVersion | Not set |
| App version | 1.0.4 / versionCode 5 |

ABIs:
- `armeabi-v7a` — 32-bit ARM
- `arm64-v8a` — 64-bit ARM
- `x86` — 32-bit Intel
- `x86_64` — 64-bit Intel

## Important: AndroidForge Gradle requirement

This is an API 36 project. It intentionally uses AGP 8.13.2 + Gradle 8.13 +
JDK 17. Google's compatibility table states that AGP 8.13 requires Gradle
8.13. Gradle 8.9 is not compatible with this plugin.

The earlier AndroidForge build screen/logs showed a standalone Gradle 8.9
fallback. To avoid repeating that failure, this ZIP includes:
- `gradlew` — Linux self-bootstrap launcher for Gradle 8.13
- `gradlew.bat` — Windows self-bootstrap launcher
- `gradle/wrapper/gradle-wrapper.properties` — pinned Gradle 8.13 URL and
  official SHA-256 checksum
- `settings.gradle` — explicit guard that stops the build if Gradle is not
  exactly 8.13

The launcher downloads Gradle 8.13 only when needed, checks the official
SHA-256 before extraction, then runs the requested Gradle task.

**AndroidForge must execute `./gradlew` (the project wrapper launcher), or
otherwise provide Gradle 8.13. Do not select the standalone Gradle 8.9
fallback.** If AndroidForge ignores the included launcher and forcibly calls
its own `gradle` 8.9 command, this API 36 project will stop with a clear
version mismatch message; do not bypass that guard. Configure the runner to
use the project wrapper/Gradle 8.13 instead.

The included GitHub Actions workflow uses Gradle 8.13, JDK 17, Android SDK
Platform 36 and Build Tools 36.0.0. It builds `assembleDebug` and uploads the
APK artifact.

## Android 16-specific native handling

### Edge-to-edge / system bars

Apps targeting Android 16 (API 36) must support edge-to-edge. The native
activity now:
- draws behind transparent status/navigation bars on Android 15 and 16;
- reads status bar, navigation bar and display-cutout insets;
- applies those insets as WebView padding so the HTML header starts below the
  status bar and the page does not sit underneath navigation controls;
- keeps the previous white system-bar layout on Android 12–14.

This is intended to preserve the HTML page layout while correctly handling
Android 15/16 enforced edge-to-edge. Physical device testing is still required.

### Back navigation

Android 13+ uses `OnBackInvokedCallback`; Android 12 uses the legacy back
callback. This avoids depending on the legacy `onBackPressed` dispatch for an
app targeting API 36.

### Large screens

The activity does not lock orientation or force a fixed aspect ratio. Android
16's large-screen behavior changes therefore do not rely on portrait-only
manifest restrictions.

## Included application behavior

- WebView JavaScript and DOM storage for the existing localStorage ledger
- Native Android document picker for JSON, CSV and Excel restore
- CSV parser supports comma, semicolon and tab delimiters, UTF-8 BOM,
  CRLF/LF/CR endings, escaped quotes and quoted multiline fields
- CSV restore validates records and customer links before replacing data;
  if saving fails, the previous in-memory database is restored
- JSON and CSV backup buttons save UTF-8 files to `Downloads/Crates Ledger`
  through MediaStore
- Blob-based ledger CSV/Excel exports are intercepted and saved natively
- SheetJS 0.18.5 is bundled locally at
  `app/src/main/assets/xlsx.full.min.js`; Excel import/export does not require
  jsDelivr or internet access
- Android PrintManager produces text/table-based print output
- Native print CSS forces white print backgrounds and avoids splitting table
  rows where supported by the print engine
- WhatsApp/SMS hand-off and Android back navigation
- Launcher icon uses the Banana Crates artwork; app label is `Crates` and
  `Ledger` on two lines

## Opening page

The supplied HTML header, logo, title, subtitle, red divider, home cards,
gradients and page background are retained. The Android-specific system inset
handling is separate from the HTML document styling. The previous requested
lower green/purple home background extension remains limited to the lower
home background and does not change button/card widths.

## Data safety

- Records remain in the app's WebView local storage.
- Clearing app storage or uninstalling the app removes local records.
- Export a JSON backup before restoring data or installing a new build.
- The workflow creates a debug APK, not a production-signed APK. A signed
  release requires a private signing key and secure signing configuration.

## Verification status

Static checks performed for this revision: Gradle/AGP version consistency,
wrapper checksum pin, SDK declarations, all four ABI filters, Android
manifest/resources, launcher assets, HTML JavaScript syntax and bundled
SheetJS syntax, and ZIP integrity.

**Not performed:** this environment has no Android SDK or installed Gradle
executable. Therefore no APK compilation is claimed here, and no physical
Android 16 device test has been performed. The AndroidForge runner must first
be confirmed to execute the included Gradle 8.13 launcher. After building,
test installation, opening page, JSON/CSV download and restore, PDF print,
back navigation, WhatsApp/SMS and data retention on the actual Android 16
phone before relying on the app for business records.


## AndroidForge Gradle Wrapper correction (v1.0.5)

This package includes a project-local Gradle bootstrap wrapper in addition to the
standard wrapper file layout. AndroidForge's README documents that its system
Gradle 8.9 is used only when a project has no usable wrapper. The earlier package
contained a shell bootstrap script but no `gradle-wrapper.jar`, so AndroidForge
classified it as having no usable wrapper and ran system Gradle 8.9.

The corrected package now includes `gradle/wrapper/gradle-wrapper.jar`,
`gradlew`, `gradlew.bat`, and a canonical `gradle-wrapper.properties` pinned to
Gradle 8.13 with SHA-256 verification. The wrapper downloads the exact Gradle
distribution on the build runner, verifies its checksum, then runs the build.
The included GitHub Actions workflow also invokes `./gradlew` rather than the
system `gradle` command.

Build configuration remains AGP 8.13.2, Gradle 8.13, JDK 17, compileSdk 36,
targetSdk 36, and minSdk 31. ABI filters include armeabi-v7a, arm64-v8a, x86,
and x86_64. This is configured for Android 12 through Android 16.

Important: this ZIP has passed package/static checks in the preparation
environment, but no Android APK was compiled here because this environment does
not have the Android SDK or Gradle distribution available. A successful AndroidForge
run is still required to confirm the actual APK build and upload.
