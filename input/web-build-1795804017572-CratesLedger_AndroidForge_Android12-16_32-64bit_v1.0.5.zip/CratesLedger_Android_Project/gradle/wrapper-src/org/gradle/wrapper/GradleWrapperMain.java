package org.gradle.wrapper;

import java.io.*;
import java.net.*;
import java.nio.file.*;
import java.security.MessageDigest;
import java.util.*;
import java.util.zip.*;

/** Minimal project-local Gradle distribution bootstrapper for restricted CI runners. */
public final class GradleWrapperMain {
  private GradleWrapperMain() {}

  public static void main(String[] args) throws Exception {
    Path project = Paths.get(System.getProperty("user.dir")).toAbsolutePath().normalize();
    Path propsPath = project.resolve("gradle/wrapper/gradle-wrapper.properties");
    if (!Files.isRegularFile(propsPath)) fail("Missing " + propsPath);
    Properties p = new Properties();
    try (InputStream in = Files.newInputStream(propsPath)) { p.load(in); }
    String urlText = required(p, "distributionUrl");
    String expectedSha = p.getProperty("distributionSha256Sum", "").trim().toLowerCase(Locale.ROOT);
    URL url = new URL(urlText.replace("\\:", ":"));
    String fileName = Paths.get(url.getPath()).getFileName().toString();
    if (!fileName.endsWith(".zip")) fail("Gradle distribution URL must end in .zip: " + urlText);
    String distName = fileName.substring(0, fileName.length() - 4);
    String userHome = System.getenv("GRADLE_USER_HOME");
    Path gradleHome = (userHome == null || userHome.isBlank()
        ? Paths.get(System.getProperty("user.home"), ".gradle") : Paths.get(userHome))
        .resolve("wrapper/dists").resolve(distName).resolve("androidforge-wrapper");
    Path gradleDir = gradleHome.resolve(distName);
    Path zip = gradleHome.resolve(fileName);
    Path gradleBin = gradleDir.resolve("bin").resolve(isWindows() ? "gradle.bat" : "gradle");

    if (!Files.isRegularFile(gradleBin) || (!isWindows() && !Files.isExecutable(gradleBin))) {
      Files.createDirectories(gradleHome);
      if (!Files.isRegularFile(zip)) download(url, zip);
      if (!expectedSha.isEmpty()) {
        String actual = sha256(zip);
        if (!actual.equals(expectedSha)) {
          Files.deleteIfExists(zip);
          fail("Gradle distribution SHA-256 mismatch. Expected " + expectedSha + ", got " + actual);
        }
      }
      extract(zip, gradleHome);
      if (!Files.isRegularFile(gradleBin) || (!isWindows() && !Files.isExecutable(gradleBin))) {
        Path alternate = gradleHome.resolve("bin").resolve("gradle");
        if (Files.isRegularFile(alternate) && !isWindows()) alternate.toFile().setExecutable(true);
      }
      if (!Files.isRegularFile(gradleBin) || (!isWindows() && !Files.isExecutable(gradleBin))) fail("Gradle executable was not found after extracting " + fileName);
    }

    List<String> command = new ArrayList<>();
    if (isWindows()) { command.add("cmd.exe"); command.add("/c"); }
    command.add(gradleBin.toString());
    command.addAll(Arrays.asList(args));
    ProcessBuilder pb = new ProcessBuilder(command).directory(project.toFile()).inheritIO();
    pb.environment().put("GRADLE_USER_HOME", userHome == null || userHome.isBlank()
        ? Paths.get(System.getProperty("user.home"), ".gradle").toString() : userHome);
    int code = pb.start().waitFor();
    System.exit(code);
  }

  private static String required(Properties p, String key) throws IOException {
    String v = p.getProperty(key);
    if (v == null || v.trim().isEmpty()) throw new IOException("Missing property: " + key);
    return v.trim();
  }
  private static boolean isWindows() { return System.getProperty("os.name", "").toLowerCase(Locale.ROOT).contains("win"); }
  private static void fail(String m) throws IOException { throw new IOException(m); }
  private static void download(URL url, Path target) throws IOException {
    System.out.println("Downloading pinned Gradle distribution: " + url);
    URLConnection c = url.openConnection();
    c.setConnectTimeout(30000); c.setReadTimeout(120000);
    Path tmp = target.resolveSibling(target.getFileName() + ".part");
    try (InputStream in = new BufferedInputStream(c.getInputStream());
         OutputStream out = new BufferedOutputStream(Files.newOutputStream(tmp))) {
      byte[] b = new byte[65536]; int n;
      while ((n = in.read(b)) >= 0) out.write(b, 0, n);
    } catch (IOException e) { Files.deleteIfExists(tmp); throw e; }
    Files.move(tmp, target, StandardCopyOption.REPLACE_EXISTING);
  }
  private static String sha256(Path file) throws Exception {
    MessageDigest md = MessageDigest.getInstance("SHA-256");
    try (InputStream in = Files.newInputStream(file)) {
      byte[] b = new byte[65536]; int n;
      while ((n = in.read(b)) >= 0) md.update(b, 0, n);
    }
    StringBuilder s = new StringBuilder();
    for (byte b : md.digest()) s.append(String.format(Locale.ROOT, "%02x", b & 0xff));
    return s.toString();
  }
  private static void extract(Path zip, Path destination) throws IOException {
    Path root = destination.toAbsolutePath().normalize();
    try (ZipInputStream zis = new ZipInputStream(new BufferedInputStream(Files.newInputStream(zip)))) {
      ZipEntry e;
      while ((e = zis.getNextEntry()) != null) {
        Path out = root.resolve(e.getName()).normalize();
        if (!out.startsWith(root)) throw new IOException("Unsafe path in Gradle distribution: " + e.getName());
        if (e.isDirectory()) Files.createDirectories(out);
        else {
          Files.createDirectories(out.getParent());
          try (OutputStream os = new BufferedOutputStream(Files.newOutputStream(out))) {
            byte[] b = new byte[65536]; int n;
            while ((n = zis.read(b)) >= 0) os.write(b, 0, n);
          }
        }
        zis.closeEntry();
      }
    }
    Path gradle = destination.resolve("gradle-8.13/bin/gradle");
    if (Files.exists(gradle)) gradle.toFile().setExecutable(true);
  }
}
