package com.bananacrates.ledger;

import android.app.Activity;
import android.os.Bundle;
import android.os.Build;
import android.content.Intent;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.net.Uri;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.ValueCallback;
import android.webkit.WebResourceRequest;
import android.webkit.JavascriptInterface;
import android.view.WindowInsets;
import android.graphics.Color;
import android.widget.Toast;
import android.print.PrintManager;
import android.print.PrintDocumentAdapter;
import android.print.PrintAttributes;
import android.util.Base64;
import java.io.OutputStream;
import java.io.InputStream;
import java.io.IOException;

public class MainActivity extends Activity {
    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;
    private static final int FILE_CHOOSER_REQUEST = 4101;
    private static final int CREATE_FILE_REQUEST = 4102;
    private String pendingBase64;
    private String pendingMime;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            getWindow().setStatusBarColor(Color.TRANSPARENT);
            getWindow().setNavigationBarColor(Color.TRANSPARENT);
            getWindow().setDecorFitsSystemWindows(false);
        }

        webView = new WebView(this);
        webView.setBackgroundColor(Color.WHITE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            webView.setOnApplyWindowInsetsListener((view, insets) -> {
                android.graphics.Insets bars = insets.getInsets(
                    WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout()
                );
                view.setPadding(bars.left, bars.top, bars.right, bars.bottom);
                return insets;
            });
        }

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(true);
        settings.setMediaPlaybackRequiresUserGesture(false);

        webView.addJavascriptInterface(new FileBridge(this), "AndroidFiles");
        webView.addJavascriptInterface(new PrintBridge(), "AndroidPrint");
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return openExternalLink(url);
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return openExternalLink(request.getUrl().toString());
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback,
                    FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = callback;
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("*/*");
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                try {
                    startActivityForResult(intent, FILE_CHOOSER_REQUEST);
                    return true;
                } catch (Exception e) {
                    filePathCallback = null;
                    Toast.makeText(MainActivity.this, "फ़ाइल चुनने का विकल्प उपलब्ध नहीं है।", Toast.LENGTH_LONG).show();
                    return false;
                }
            }
        });
        setContentView(webView);
        if (savedInstanceState == null) webView.loadUrl("file:///android_asset/index.html");
        else webView.restoreState(savedInstanceState);
    }

    private boolean openExternalLink(String url) {
        if (url == null) return false;
        Uri uri;
        try {
            uri = Uri.parse(url);
        } catch (Exception e) {
            return false;
        }
        String scheme = uri.getScheme() == null ? "" : uri.getScheme().toLowerCase();
        String host = uri.getHost() == null ? "" : uri.getHost().toLowerCase();

        // Let the installed WhatsApp app handle WhatsApp deep links and wa.me URLs.
        if ("whatsapp".equals(scheme) ||
            (("https".equals(scheme) || "http".equals(scheme)) &&
             (host.equals("wa.me") || host.endsWith(".whatsapp.com") || host.equals("whatsapp.com")))) {
            try {
                Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
                return true;
            } catch (ActivityNotFoundException e) {
                try {
                    Intent browser = new Intent(Intent.ACTION_VIEW,
                        Uri.parse("https://wa.me/" + uri.getQueryParameter("phone") +
                                  (uri.getQueryParameter("text") == null ? "" :
                                   "?text=" + Uri.encode(uri.getQueryParameter("text")))));
                    startActivity(browser);
                    return true;
                } catch (Exception ignored) {
                    Toast.makeText(this, "WhatsApp उपलब्ध नहीं है। कृपया WhatsApp इंस्टॉल करें।", Toast.LENGTH_LONG).show();
                    return true;
                }
            } catch (Exception e) {
                Toast.makeText(this, "WhatsApp खोलने में समस्या आई।", Toast.LENGTH_LONG).show();
                return true;
            }
        }

        // Open the device's SMS composer explicitly. ACTION_SENDTO is the
        // Android-supported intent for messaging apps and avoids WebView URL-scheme errors.
        if ("sms".equals(scheme) || "smsto".equals(scheme) || "mms".equals(scheme) || "mmsto".equals(scheme)) {
            try {
                String recipient = uri.getSchemeSpecificPart();
                if (recipient == null) recipient = "";
                int queryAt = recipient.indexOf('?');
                String query = queryAt >= 0 ? recipient.substring(queryAt + 1) : "";
                if (queryAt >= 0) recipient = recipient.substring(0, queryAt);
                String body = uri.getQueryParameter("body");
                if (body == null && query.startsWith("body=")) {
                    body = Uri.decode(query.substring(5));
                }
                Uri smsUri = Uri.parse("smsto:" + Uri.encode(Uri.decode(recipient)));
                Intent smsIntent = new Intent(Intent.ACTION_SENDTO, smsUri);
                if (body != null) smsIntent.putExtra("sms_body", body);
                startActivity(smsIntent);
                return true;
            } catch (Exception e) {
                Toast.makeText(this, "SMS ऐप खोलने में समस्या आई। कृपया मोबाइल में SMS ऐप जाँचें।", Toast.LENGTH_LONG).show();
                return true;
            }
        }

        // Other supported external app schemes.
        if ("mailto".equals(scheme) || "tel".equals(scheme) || "geo".equals(scheme)) {
            try {
                startActivity(new Intent(Intent.ACTION_VIEW, uri));
                return true;
            } catch (Exception e) {
                Toast.makeText(this, "इस लिंक को खोलने के लिए उपयुक्त ऐप उपलब्ध नहीं है।", Toast.LENGTH_LONG).show();
                return true;
            }
        }
        return false;
    }


    private class PrintBridge {
        @JavascriptInterface
        public void printHtml(String html, String documentName) {
            runOnUiThread(() -> startHtmlPrint(html, documentName));
        }
    }

    private void startHtmlPrint(String html, String documentName) {
        try {
            PrintManager printManager = (PrintManager) getSystemService(Context.PRINT_SERVICE);
            if (printManager == null) {
                Toast.makeText(this, "PDF / प्रिंट सेवा उपलब्ध नहीं है।", Toast.LENGTH_LONG).show();
                return;
            }

            WebView printWebView = new WebView(this);
            printWebView.setBackgroundColor(Color.WHITE);
            printWebView.getSettings().setJavaScriptEnabled(true);
            printWebView.setWebViewClient(new WebViewClient() {
                @Override
                public void onPageFinished(WebView view, String url) {
                    super.onPageFinished(view, url);
                    try {
                        String jobName = (documentName == null || documentName.trim().isEmpty())
                            ? "Crates-Ledger" : documentName.replaceAll("[^A-Za-z0-9 _-]", "_");
                        PrintDocumentAdapter adapter = view.createPrintDocumentAdapter(jobName);
                        PrintAttributes attributes = new PrintAttributes.Builder()
                            .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                            .setResolution(new PrintAttributes.Resolution("pdf", "PDF", 300, 300))
                            .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                            .build();
                        printManager.print(jobName, adapter, attributes);
                    } catch (Exception e) {
                        Toast.makeText(MainActivity.this, "PDF तैयार नहीं हो सका।", Toast.LENGTH_LONG).show();
                        view.destroy();
                    }
                }
            });
            printWebView.loadDataWithBaseURL(
                "file:///android_asset/", html, "text/html", "UTF-8", null
            );
        } catch (Exception e) {
            Toast.makeText(this, "PDF / प्रिंट शुरू नहीं हो सका।", Toast.LENGTH_LONG).show();
        }
    }

    private class FileBridge {
        private final Context context;
        FileBridge(Context c) { context = c; }

        @JavascriptInterface
        public void saveFile(String fileName, String mimeType, String base64Data) {
            runOnUiThread(() -> {
                pendingBase64 = base64Data;
                pendingMime = (mimeType == null || mimeType.isEmpty()) ? "application/octet-stream" : mimeType;
                Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType(pendingMime);
                intent.putExtra(Intent.EXTRA_TITLE, fileName == null ? "Crates-Ledger-Backup" : fileName);
                try {
                    startActivityForResult(intent, CREATE_FILE_REQUEST);
                } catch (Exception e) {
                    pendingBase64 = null;
                    Toast.makeText(MainActivity.this, "फ़ाइल सेव करने का विकल्प उपलब्ध नहीं है।", Toast.LENGTH_LONG).show();
                }
            });
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER_REQUEST) {
            if (filePathCallback != null) {
                Uri[] result = (resultCode == RESULT_OK && data != null && data.getData() != null)
                    ? new Uri[]{data.getData()} : null;
                filePathCallback.onReceiveValue(result);
                filePathCallback = null;
            }
            return;
        }
        if (requestCode == CREATE_FILE_REQUEST) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null && pendingBase64 != null) {
                try (OutputStream output = getContentResolver().openOutputStream(data.getData())) {
                    byte[] bytes = Base64.decode(pendingBase64, Base64.DEFAULT);
                    if (output != null) {
                        output.write(bytes);
                        Toast.makeText(this, "फ़ाइल सफलतापूर्वक सेव हो गई।", Toast.LENGTH_LONG).show();
                    }
                } catch (Exception e) {
                    Toast.makeText(this, "फ़ाइल सेव नहीं हो सकी।", Toast.LENGTH_LONG).show();
                }
            }
            pendingBase64 = null;
            pendingMime = null;
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        if (webView != null) webView.saveState(outState);
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (filePathCallback != null) {
            filePathCallback.onReceiveValue(null);
            filePathCallback = null;
        }
        if (webView != null) {
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
