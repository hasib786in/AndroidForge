CRATES LEDGER - ANDROIDFORGE PROJECT

Android compatibility:
- Android 12: API 31 (minimum supported version)
- Android 13: API 33
- Android 14: API 34
- Android 15: API 35
- Android 16: API 36 (compile/target SDK)

Configured ABIs:
- armeabi-v7a: 32-bit ARM
- arm64-v8a: 64-bit ARM
- x86 and x86_64: emulator compatibility

Launcher label resource:
- Crates
- Ledger
(two-line label using an Android string newline escape)

Build:
- Android Gradle Plugin: 8.9.1
- Gradle wrapper: 8.11.1
- Compile SDK: 36
- Minimum SDK: 31
- Target SDK: 36

Build the APK in AndroidForge or with the included Gradle wrapper.
This ZIP is an Android project source package, not a prebuilt APK.
