CRATES LEDGER — ANDROIDFORGE PROJECT

APPLICATION
- Launcher display name: Crates / Ledger (two-line label where supported by the launcher)
- Application ID: com.bananacrates.ledger
- Launcher artwork: existing Banana Crates icon and adaptive icon assets
- Main application: app/src/main/assets/index.html
- WebView wrapper: app/src/main/java/com/bananacrates/ledger/MainActivity.java

ANDROID COMPATIBILITY
- Minimum Android version: Android 12 (API 31)
- Configured compile SDK: Android 16 (API 36)
- Configured target SDK: Android 16 (API 36)
- 32-bit ARM: armeabi-v7a
- 64-bit ARM: arm64-v8a
- x86 and x86_64 are also included for compatible emulators

BUILD TOOLCHAIN
- Android Gradle Plugin: 8.9.1
- Gradle wrapper: 8.11.1
- JDK: 17
- Android SDK Platform 36

IMPORTANT ANDROIDFORGE NOTE
This project is configured for API 36 and uses the matching AGP/Gradle combination.
AndroidForge must run the included Gradle wrapper (Gradle 8.11.1) or an equivalent
compatible Gradle version. A build environment that forcibly uses Gradle 8.9
instead of the wrapper is not compatible with AGP 8.9.1 and must be updated.

PRESERVED ANDROID INTEGRATIONS
- Android WebView file picker for restore/import workflows
- Android system Save File dialog for supported exports
- Native Android PrintManager bridge for customer ledger printing
- External app hand-off for WhatsApp, SMS, telephone, email, and geo links
- Existing Banana Crates launcher icon resources and two-line app label

WEB APP CONTENT
The HTML asset is the final corrected file:
Crates-Ledger-Due-Balance-CALCULATION-FIXED.html
It includes the corrected due-balance calculation and preserves the web application's
existing interface and features as supplied in that final HTML file.

BUILD
1. Upload this ZIP to AndroidForge.
2. Ensure AndroidForge uses the included Gradle wrapper / Gradle 8.11.1, AGP 8.9.1,
   JDK 17, and Android SDK Platform 36.
3. Run the APK build.

This ZIP is an Android source project, not a prebuilt APK. The project has been
packaged and its contents checked, but an AndroidForge APK build and physical-device
testing have not been performed here. Actual behavior should be verified on Android
12–16 devices, especially file import/export, printing, WhatsApp/SMS hand-off, and
ledger data persistence.

LAUNCHER DISPLAY NAME
The launcher label is deliberately two lines: Crates (line 1), Ledger (line 2).
The app and launcher activity both reference @string/app_name. Keep the \n escape in app/src/main/res/values/strings.xml; do not replace it with a space.
