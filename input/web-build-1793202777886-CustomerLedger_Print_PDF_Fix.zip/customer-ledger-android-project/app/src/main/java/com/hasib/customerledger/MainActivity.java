package com.hasib.customerledger;

import android.app.Activity;
import android.content.Intent;
import android.content.ActivityNotFoundException;
import android.content.pm.PackageManager;
import android.webkit.WebResourceRequest;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import android.net.Uri;
import android.os.Bundle;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.util.Base64;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.JavascriptInterface;
import android.widget.Toast;
import java.io.OutputStream;

public class MainActivity extends Activity {
    private static final int CREATE_FILE_REQUEST = 4101;
    private static final int OPEN_FILE_REQUEST = 4102;
    private WebView webView;
    private byte[] pendingBytes;
    private String pendingMime = "application/octet-stream";
    private ValueCallback<Uri[]> filePathCallback;

    public class AndroidBridge {
        @JavascriptInterface
        public void openSms(String phone, String message) {
            runOnUiThread(() -> {
                try {
                    String safePhone = phone == null ? "" : phone.trim();
                    Intent sms = new Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(safePhone)));
                    if (message != null) sms.putExtra("sms_body", message);
                    if (sms.resolveActivity(getPackageManager()) != null) {
                        startActivity(sms);
                    } else {
                        Toast.makeText(MainActivity.this, "इस फ़ोन में SMS ऐप उपलब्ध नहीं है।", Toast.LENGTH_LONG).show();
                    }
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "SMS ऐप नहीं खुल सका। कृपया डिफ़ॉल्ट SMS ऐप जाँचें।", Toast.LENGTH_LONG).show();
                }
            });
        }

        @JavascriptInterface
        public void printPage() {
            runOnUiThread(() -> {
                try {
                    PrintManager printManager = (PrintManager) getSystemService(PRINT_SERVICE);
                    if (printManager == null || webView == null) {
                        Toast.makeText(MainActivity.this, "प्रिंट सेवा उपलब्ध नहीं है।", Toast.LENGTH_LONG).show();
                        return;
                    }
                    PrintAttributes attributes = new PrintAttributes.Builder()
                            .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                            .setResolution(new PrintAttributes.Resolution("customer_ledger_pdf", "PDF Printer", 300, 300))
                            .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                            .build();
                    printManager.print("Customer Ledger", webView.createPrintDocumentAdapter("Customer Ledger"), attributes);
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "प्रिंट/PDF शुरू नहीं हो सका। कृपया दोबारा कोशिश करें।", Toast.LENGTH_LONG).show();
                }
            });
        }

        @JavascriptInterface
        public void saveFile(String name, String mime, String base64) {
            try {
                pendingBytes = Base64.decode(base64, Base64.DEFAULT);
                pendingMime = (mime == null || mime.isEmpty()) ? "application/octet-stream" : mime;
                runOnUiThread(() -> {
                    Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType(pendingMime);
                    intent.putExtra(Intent.EXTRA_TITLE, name == null ? "backup.json" : name);
                    startActivityForResult(intent, CREATE_FILE_REQUEST);
                });
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "फ़ाइल तैयार नहीं हुई", Toast.LENGTH_LONG).show());
            }
        }
    }

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        webView.addJavascriptInterface(new AndroidBridge(), "AndroidBridge");
        webView.setWebViewClient(new WebViewClient() {
            private boolean handleExternalUrl(String url) {
                if (url == null) return false;
                try {
                    Uri uri = Uri.parse(url);
                    String scheme = uri.getScheme() == null ? "" : uri.getScheme().toLowerCase();
                    if ("sms".equals(scheme) || "smsto".equals(scheme) || "mmsto".equals(scheme)) {
                        String phone = uri.getSchemeSpecificPart();
                        if (phone != null) {
                            int q = phone.indexOf('?');
                            if (q >= 0) phone = phone.substring(0, q);
                        }
                        String body = uri.getQueryParameter("body");
                        Intent sms = new Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + (phone == null ? "" : phone)));
                        if (body != null) sms.putExtra("sms_body", body);
                        startActivity(sms);
                        return true;
                    }
                    if ("https".equals(scheme) || "http".equals(scheme) || "whatsapp".equals(scheme) || "mailto".equals(scheme) || "tel".equals(scheme)) {
                        // Open WhatsApp/web share links and other external schemes outside the WebView.
                        if ("https".equals(scheme) || "http".equals(scheme)) {
                            String host = uri.getHost();
                            if (host == null || !(host.equalsIgnoreCase("wa.me") || host.toLowerCase().endsWith(".whatsapp.com") || host.equalsIgnoreCase("whatsapp.com"))) {
                                return false;
                            }
                        }
                        Intent external = new Intent(Intent.ACTION_VIEW, uri);
                        startActivity(external);
                        return true;
                    }
                } catch (ActivityNotFoundException e) {
                    Toast.makeText(MainActivity.this, "संबंधित ऐप उपलब्ध नहीं है। कृपया WhatsApp या SMS ऐप इंस्टॉल करें।", Toast.LENGTH_LONG).show();
                    return true;
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "लिंक नहीं खुल सका। कृपया दोबारा कोशिश करें।", Toast.LENGTH_LONG).show();
                    return true;
                }
                return false;
            }

            @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return handleExternalUrl(url);
            }

            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return handleExternalUrl(request.getUrl().toString());
            }

            @Override public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                // Route the web app's existing window.print() buttons to Android's native print/PDF dialog.
                view.evaluateJavascript("window.print = function(){ if(window.AndroidBridge && window.AndroidBridge.printPage){ window.AndroidBridge.printPage(); } else { alert('प्रिंट सुविधा उपलब्ध नहीं है।'); } };", null);
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = callback;
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("application/json");
                intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"application/json", "text/json", "application/octet-stream", "*/*"});
                try { startActivityForResult(intent, OPEN_FILE_REQUEST); }
                catch (Exception e) { filePathCallback = null; callback.onReceiveValue(null); return false; }
                return true;
            }
        });
        if (savedInstanceState == null) webView.loadUrl("file:///android_asset/index.html");
        else if (webView.restoreState(savedInstanceState) == null) webView.loadUrl("file:///android_asset/index.html");
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == CREATE_FILE_REQUEST) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null && pendingBytes != null) {
                try (OutputStream out = getContentResolver().openOutputStream(data.getData())) {
                    if (out == null) throw new Exception("फ़ाइल नहीं खुली");
                    out.write(pendingBytes); out.flush();
                    Toast.makeText(this, "फ़ाइल सफलतापूर्वक सेव हुई", Toast.LENGTH_LONG).show();
                } catch (Exception e) { Toast.makeText(this, "फ़ाइल सेव नहीं हुई: " + e.getMessage(), Toast.LENGTH_LONG).show(); }
            }
            pendingBytes = null;
        } else if (requestCode == OPEN_FILE_REQUEST && filePathCallback != null) {
            Uri[] result = (resultCode == RESULT_OK && data != null && data.getData() != null) ? new Uri[]{data.getData()} : null;
            filePathCallback.onReceiveValue(result);
            filePathCallback = null;
        }
    }

    @Override protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        if (webView != null) webView.saveState(outState);
    }
    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
}
