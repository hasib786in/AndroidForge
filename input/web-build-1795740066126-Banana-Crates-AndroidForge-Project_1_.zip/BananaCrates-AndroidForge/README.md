# Banana Crates Ledger — AndroidForge source project

Android WebView wrapper for the supplied Crates Ledger HTML app.

## Build configuration
- Android Gradle Plugin: 8.11.1
- Gradle wrapper distribution: 8.13
- JDK: 17
- compileSdk / targetSdk: 36
- minSdk: 31 (Android 12)
- ABI filters: armeabi-v7a and arm64-v8a
- Launcher label resource: `Crates\nLedger` (two-line label request)
- Launcher icon: supplied Banana Crates logo, adaptive and density-specific assets

## Notes for AndroidForge
The Gradle wrapper properties pin Gradle 8.13. The wrapper JAR is intentionally not bundled; AndroidForge's documented missing-wrapper-JAR recovery can regenerate it using its installed Gradle before invoking the wrapper. If the selected AndroidForge workflow does not perform that recovery, add the official Gradle wrapper JAR for Gradle 8.13 before building.

The original HTML is stored at `app/src/main/assets/index.html`. It uses browser localStorage for ledger data and currently loads SheetJS from jsDelivr for Excel features, so Excel functionality requires internet access. Core ledger UI and data are packaged locally.
