Banana Suppliers Ledger - AndroidForge project

Import this ZIP into AndroidForge as an Android source project.

App:
- Installed display name: B. Supplier Ledger
- Package: com.hasibkhan.bananasuppliersledger
- Min Android: 6.0 (API 23)
- Compile/Target SDK: 35
- Java: 17
- App type: Native Android WebView wrapper around the supplied HTML ledger.

Build:
1. Upload this ZIP to your AndroidForge web UI.
2. Select Android and Debug (first build recommended).
3. Start Build APK and download the generated APK artifact.

Notes:
- The HTML app is bundled at app/src/main/assets/index.html.
- JavaScript and DOM storage are enabled so the ledger UI and localStorage data work in WebView.
- Internet permission is included because the HTML application uses an external SheetJS CDN for spreadsheet features.
- WhatsApp/SMS actions are handed to Android apps through URL intents.
- Imported files can be selected through the Android file picker.
- This ZIP is the Android project source, not a prebuilt APK.

Launcher icon: included in mipmap resources (legacy PNG and Android 8.0+ adaptive icon). The installed app should display the B. Supplier Ledger icon in the launcher.


CUSTOM LAUNCHER ICON
--------------------
The launcher icon has been replaced with the image supplied by the project owner.
Density-specific PNG icons are included for mdpi, hdpi, xhdpi, xxhdpi and xxxhdpi,
and adaptive icon resources are included for Android 8.0 and newer.
Import this project ZIP into AndroidForge and build a fresh APK. Reinstall/update
the newly built APK to see the new launcher icon.

DISPLAY NAME AND ICON SIZE UPDATE
---------------------------------
Installed launcher label: B. Supplier Ledger.
The icon artwork has been enlarged by approximately 8% inside the existing icon canvas
(roughly equivalent to 1 mm on a typical launcher icon). Android launchers control
the actual on-screen icon dimensions, so an exact physical 1 mm increase cannot be
forced by an APK across all devices.
