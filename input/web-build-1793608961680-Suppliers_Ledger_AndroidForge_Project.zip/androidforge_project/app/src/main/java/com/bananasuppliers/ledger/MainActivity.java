package com.bananasuppliers.ledger;

import android.app.Activity;
import android.app.DownloadManager;
import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.view.View;
import android.webkit.DownloadListener;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;

public class MainActivity extends Activity {
    private FrameLayout root;
    private WebView mainWebView;
    private ValueCallback<Uri[]> filePathCallback;
    private static final int FILE_CHOOSER_REQUEST = 4102;
    private int popupCount = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        root = new FrameLayout(this);
        mainWebView = createWebView(false);
        root.addView(mainWebView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        setContentView(root);
        mainWebView.loadUrl("file:///android_asset/index.html");
    }

    private WebView createWebView(boolean popup) {
        WebView webView = new WebView(this);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(true);
        settings.setSupportMultipleWindows(true);
        settings.setLoadsImagesAutomatically(true);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        webView.addJavascriptInterface(new NativeBridge(webView), "AndroidBridge");

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return handleSpecialUrl(request.getUrl().toString());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return handleSpecialUrl(url);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                installNativeHooks(view);
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> callback,
                                               FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = callback;
                Intent intent;
                try {
                    intent = params.createIntent();
                } catch (Exception e) {
                    filePathCallback = null;
                    return false;
                }
                startActivityForResult(intent, FILE_CHOOSER_REQUEST);
                return true;
            }

            @Override
            public boolean onCreateWindow(WebView view, boolean isDialog,
                                          boolean isUserGesture, android.os.Message resultMsg) {
                WebView child = createWebView(true);
                child.setBackgroundColor(android.graphics.Color.WHITE);
                FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(
                        FrameLayout.LayoutParams.MATCH_PARENT,
                        FrameLayout.LayoutParams.MATCH_PARENT);
                root.addView(child, params);
                child.setTag("popup_" + (++popupCount));
                WebView.WebViewTransport transport = (WebView.WebViewTransport) resultMsg.obj;
                transport.setWebView(child);
                resultMsg.sendToTarget();
                return true;
            }
        });

        webView.setDownloadListener((url, userAgent, contentDisposition, mimeType, contentLength) -> {
            try {
                DownloadManager.Request request = new DownloadManager.Request(Uri.parse(url));
                request.setMimeType(mimeType);
                request.addRequestHeader("User-Agent", userAgent);
                request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS,
                        "BananaLedger-" + System.currentTimeMillis());
                ((DownloadManager) getSystemService(DOWNLOAD_SERVICE)).enqueue(request);
                Toast.makeText(MainActivity.this, "डाउनलोड शुरू हो गया", Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                Toast.makeText(MainActivity.this, "डाउनलोड नहीं हो सका", Toast.LENGTH_LONG).show();
            }
        });
        return webView;
    }

    private void installNativeHooks(WebView view) {
        String js = "(function(){"
                + "try{window.print=function(){if(window.AndroidBridge){window.AndroidBridge.printPage(document.title||'Banana Suppliers Ledger');}};}catch(e){}"
                + "if(window.__androidDownloadHook)return;window.__androidDownloadHook=true;"
                + "document.addEventListener('click',function(ev){var a=ev.target&&ev.target.closest?ev.target.closest('a[download]'):null;if(!a)return;var u=a.href||'',n=a.download||'ledger-export',m='application/octet-stream';"
                + "if(u.indexOf('blob:')===0){ev.preventDefault();fetch(u).then(function(r){m=r.headers.get('content-type')||m;return r.arrayBuffer();}).then(function(b){var bytes=new Uint8Array(b),bin='';for(var i=0;i<bytes.length;i+=0x8000)bin+=String.fromCharCode.apply(null,bytes.subarray(i,i+0x8000));window.AndroidBridge.saveBase64File(n,m,btoa(bin));}).catch(function(){alert('फ़ाइल सेव नहीं हो सकी।');});}"
                + "else if(u.indexOf('data:')===0){ev.preventDefault();var p=u.split(','),h=p[0],d=p.slice(1).join(',');m=(h.match(/data:([^;]+)/)||[])[1]||m;var b=h.indexOf(';base64')>=0?d:btoa(unescape(decodeURIComponent(d)));window.AndroidBridge.saveBase64File(n,m,b);}},true);"
                + "})();";
        view.evaluateJavascript(js, null);
    }

    private boolean handleSpecialUrl(String url) {
        if (url.startsWith("sms:") || url.startsWith("tel:") || url.startsWith("mailto:")
                || url.startsWith("whatsapp:") || url.startsWith("intent:")) {
            try {
                Intent intent = url.startsWith("intent:")
                        ? Intent.parseUri(url, Intent.URI_INTENT_SCHEME)
                        : new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                startActivity(intent);
            } catch (Exception e) {
                Toast.makeText(this, "इस सुविधा के लिए संबंधित ऐप उपलब्ध नहीं है", Toast.LENGTH_SHORT).show();
            }
            return true;
        }
        return false;
    }

    private void printWebView(WebView target, String title) {
        runOnUiThread(() -> {
            try {
                PrintManager printManager = (PrintManager) getSystemService(PRINT_SERVICE);
                String jobName = (title == null || title.trim().isEmpty())
                        ? "Banana Suppliers Ledger" : title;
                printManager.print(jobName, target.createPrintDocumentAdapter(jobName),
                        new PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                                .setResolution(new PrintAttributes.Resolution("pdf", "PDF", 300, 300))
                                .setMinMargins(PrintAttributes.Margins.NO_MARGINS).build());
            } catch (Exception e) {
                Toast.makeText(this, "PDF प्रिंट शुरू नहीं हो सका", Toast.LENGTH_LONG).show();
            }
        });
    }

    private void saveBase64File(String filename, String mimeType, String base64) {
        try {
            byte[] bytes;
            bytes = android.util.Base64.decode(base64, android.util.Base64.DEFAULT);
            String safeName = filename == null ? "ledger-backup" : filename.replaceAll("[/\\\\:*?\"<>|]", "_");
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                ContentValues values = new ContentValues();
                values.put(MediaStore.Downloads.DISPLAY_NAME, safeName);
                values.put(MediaStore.Downloads.MIME_TYPE, mimeType == null ? "application/octet-stream" : mimeType);
                values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Banana Suppliers Ledger");
                Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                if (uri == null) throw new Exception("Unable to create download");
                try (OutputStream out = getContentResolver().openOutputStream(uri)) { out.write(bytes); }
            } else {
                File dir = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
                if (dir == null) throw new Exception("No download directory");
                if (!dir.exists()) dir.mkdirs();
                try (FileOutputStream out = new FileOutputStream(new File(dir, safeName))) { out.write(bytes); }
            }
            runOnUiThread(() -> Toast.makeText(this, "फ़ाइल Downloads में सेव हो गई", Toast.LENGTH_LONG).show());
        } catch (Exception e) {
            runOnUiThread(() -> Toast.makeText(this, "फ़ाइल सेव नहीं हो सकी", Toast.LENGTH_LONG).show());
        }
    }

    public class NativeBridge {
        private final WebView target;
        NativeBridge(WebView target) { this.target = target; }
        @JavascriptInterface public void printPage(String title) { printWebView(target, title); }
        @JavascriptInterface public void saveBase64File(String name, String mime, String data) {
            MainActivity.this.saveBase64File(name, mime, data);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER_REQUEST && filePathCallback != null) {
            Uri[] results = null;
            if (resultCode == RESULT_OK && data != null) {
                Uri uri = data.getData();
                if (uri != null) results = new Uri[]{uri};
            }
            filePathCallback.onReceiveValue(results);
            filePathCallback = null;
        }
    }

    @Override
    public void onBackPressed() {
        if (root != null && root.getChildCount() > 1) {
            View top = root.getChildAt(root.getChildCount() - 1);
            if (top instanceof WebView) {
                ((WebView) top).destroy();
                root.removeView(top);
                return;
            }
        }
        if (mainWebView != null && mainWebView.canGoBack()) mainWebView.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (mainWebView != null) mainWebView.destroy();
        super.onDestroy();
    }
}
