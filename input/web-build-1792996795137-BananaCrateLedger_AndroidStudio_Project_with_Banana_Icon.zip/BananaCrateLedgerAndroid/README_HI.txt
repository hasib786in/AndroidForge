केला क्रेट लेजर Android प्रोजेक्ट

महत्वपूर्ण: यह Android Studio में APK बनाने के लिए प्रोजेक्ट सोर्स है, पहले से बना हुआ APK नहीं।
इस रनटाइम में Android SDK/Gradle उपलब्ध नहीं होने के कारण यहाँ सीधे installable APK compile नहीं किया जा सका।

APK बनाने के तरीके:
1. कंप्यूटर पर Android Studio इंस्टॉल करें।
2. Android Studio में Open चुनें और इस ZIP को extract करके BananaCrateLedger फ़ोल्डर खोलें।
3. Gradle sync पूरा होने दें (इंटरनेट आवश्यक हो सकता है)।
4. Build > Build Bundle(s) / APK(s) > Build APK(s) चुनें।
5. APK सामान्यतः app/build/outputs/apk/debug/app-debug.apk पर मिलेगा।

ऐप HTML लेजर को Android WebView में चलाता है। ग्राहक/लेनदेन डेटा WebView के local storage में उसी फोन पर सेव होता है।
डेटा मिटाने/ऐप हटाने से पहले JSON बैकअप लें। दूसरे फोन पर डेटा लाने के लिए JSON या Excel बैकअप Restore करें।
Excel फीचर के लिए इंटरनेट चाहिए क्योंकि XLSX लाइब्रेरी CDN से लोड होती है।
ऑनलाइन क्लाउड सिंक इस प्रोजेक्ट में सेटअप नहीं है।
