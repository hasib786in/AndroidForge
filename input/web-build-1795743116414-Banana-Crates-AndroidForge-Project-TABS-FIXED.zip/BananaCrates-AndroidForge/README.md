# Banana Crates Ledger — AndroidForge source project

Android WebView wrapper for the supplied Crates Ledger HTML app.

## Build configuration
- Android Gradle Plugin: 8.11.1
- Gradle runtime: 8.13 (pinned and SHA-256 verified)
- JDK: 17
- compileSdk / targetSdk: 36
- minSdk: 31 (Android 12)
- ABI filters: armeabi-v7a and arm64-v8a
- Launcher label resource: `Crates\nLedger` (two-line label request)
- Launcher icon: supplied Banana Crates logo, adaptive and density-specific assets

## Gradle 8.13 bootstrap fix
The previous ZIP did not include a usable Gradle Wrapper bootstrap JAR. AndroidForge therefore fell back to its preinstalled system Gradle 8.9, producing the reported error that AGP requires Gradle 8.13.

This revision includes a small project-specific Java bootstrap in `gradle/wrapper/gradle-wrapper.jar`. The included `gradlew` script invokes it. It downloads the official Gradle 8.13 binary distribution from `services.gradle.org`, verifies the official SHA-256 (`20f1b1176237254a6fc204d8434196fa11a4cfb387567519c61556e8710aed78`), extracts it under `GRADLE_USER_HOME`, and runs that Gradle executable. This is a project-specific bootstrap, not Gradle's stock wrapper JAR; do not replace it with an unrelated JAR.

The wrapper properties also pin Gradle 8.13 and its official distribution checksum. On Linux, `gradlew` is executable.

## App contents
The original HTML is stored at `app/src/main/assets/index.html`. It uses browser localStorage for ledger data and currently loads SheetJS from jsDelivr for Excel features, so Excel functionality requires internet access. Core ledger UI and data are packaged locally.
