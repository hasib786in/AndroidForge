package com.bananacrates.ledger;

import android.app.Activity;
import android.app.DownloadManager;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

public class MainActivity extends Activity {
    private WebView webView;
    private ValueCallback<Uri[]> fileCallback;
    private static final int PICK_FILE = 4102;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(android.graphics.Color.rgb(23,107,69));
        getWindow().setNavigationBarColor(android.graphics.Color.BLACK);
        webView = new WebView(this);
        setContentView(webView);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true); s.setAllowContentAccess(true);
        s.setJavaScriptCanOpenWindowsAutomatically(true); s.setSupportMultipleWindows(false);
        s.setDefaultTextEncodingName("UTF-8");
        CookieManager.getInstance().setAcceptCookie(true);
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                Intent intent = params.createIntent();
                try { startActivityForResult(intent, PICK_FILE); } catch (ActivityNotFoundException e) { fileCallback=null; callback.onReceiveValue(null); Toast.makeText(MainActivity.this,"No file picker available",Toast.LENGTH_LONG).show(); }
                return true;
            }
        });
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri=request.getUrl(); String scheme=uri.getScheme()==null?"":uri.getScheme();
                if (scheme.equals("http") || scheme.equals("https") || scheme.equals("whatsapp") || scheme.equals("sms") || scheme.equals("tel") || scheme.equals("mailto")) {
                    try { startActivity(new Intent(Intent.ACTION_VIEW,uri)); } catch(Exception e) { Toast.makeText(MainActivity.this,"No compatible app found",Toast.LENGTH_SHORT).show(); }
                    return true;
                }
                return false;
            }
        });
        webView.setDownloadListener((url, ua, disposition, mime, length) -> {
            try {
                DownloadManager.Request req=new DownloadManager.Request(Uri.parse(url));
                req.setMimeType(mime); req.addRequestHeader("User-Agent",ua);
                req.setTitle(disposition==null?"Crates Ledger download":disposition);
                req.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                req.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS,"CratesLedger-"+System.currentTimeMillis());
                ((DownloadManager)getSystemService(DOWNLOAD_SERVICE)).enqueue(req);
                Toast.makeText(this,"Download started",Toast.LENGTH_SHORT).show();
            } catch(Exception e) { Toast.makeText(this,"Download could not start",Toast.LENGTH_LONG).show(); }
        });
        if (state == null) webView.loadUrl("file:///android_asset/index.html"); else webView.restoreState(state);
    }
    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode==PICK_FILE && fileCallback!=null){ Uri[] result=null; if(resultCode==RESULT_OK && data!=null && data.getData()!=null) result=new Uri[]{data.getData()}; fileCallback.onReceiveValue(result); fileCallback=null; }
    }
    @Override protected void onSaveInstanceState(Bundle out) { if(webView!=null) webView.saveState(out); super.onSaveInstanceState(out); }
    @Override public void onBackPressed() { if(webView!=null && webView.canGoBack()) webView.goBack(); else super.onBackPressed(); }
    @Override protected void onDestroy() { if(webView!=null){webView.destroy();webView=null;} super.onDestroy(); }
}
