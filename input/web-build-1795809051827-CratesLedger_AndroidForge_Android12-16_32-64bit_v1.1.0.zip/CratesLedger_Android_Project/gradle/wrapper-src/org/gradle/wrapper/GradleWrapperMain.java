package org.gradle.wrapper;

import java.io.*;
import java.net.*;
import java.nio.file.*;
import java.security.MessageDigest;
import java.util.*;
import java.util.zip.*;

/**
 * AndroidForge-safe Gradle distribution bootstrapper.
 * Uses ZipFile (central-directory aware) rather than ZipInputStream so
 * ZIP64/large Gradle distributions are extracted reliably.
 */
public final class GradleWrapperMain {
  private GradleWrapperMain() {}

  public static void main(String[] args) throws Exception {
    Path project = Paths.get(System.getProperty("user.dir")).toAbsolutePath().normalize();
    Path propsPath = project.resolve("gradle/wrapper/gradle-wrapper.properties");
    if (!Files.isRegularFile(propsPath)) fail("Missing wrapper properties: " + propsPath);

    Properties p = new Properties();
    try (InputStream in = Files.newInputStream(propsPath)) { p.load(in); }

    String urlText = required(p, "distributionUrl").replace("\\:", ":");
    String expectedSha = p.getProperty("distributionSha256Sum", "").trim().toLowerCase(Locale.ROOT);
    URL url = new URL(urlText);
    String fileName = Paths.get(url.getPath()).getFileName().toString();
    if (!fileName.endsWith(".zip")) fail("Gradle distribution URL must end in .zip: " + urlText);
    String distName = fileName.substring(0, fileName.length() - 4);
    // Gradle ZIP filename includes the distribution type suffix (-bin/-all),
    // but the directory inside the ZIP does not.
    String distributionFolderName = distName.replaceFirst("-(bin|all)$", "");

    String userHome = System.getenv("GRADLE_USER_HOME");
    Path gradleUserHome = (userHome == null || userHome.trim().isEmpty())
        ? Paths.get(System.getProperty("user.home"), ".gradle")
        : Paths.get(userHome);
    Path wrapperHome = gradleUserHome.resolve("wrapper").resolve("dists")
        .resolve(distName).resolve("androidforge-wrapper");
    Path zip = wrapperHome.resolve(fileName);

    Path gradleBin = findGradleExecutable(wrapperHome, distributionFolderName);
    if (gradleBin == null) {
      Files.createDirectories(wrapperHome);
      ensureDistribution(url, zip, expectedSha);
      Path extractionRoot = wrapperHome.resolve("extracting");
      deleteTree(extractionRoot);
      Files.createDirectories(extractionRoot);
      try {
        extractWithZipFile(zip, extractionRoot);
        Path extractedBin = findGradleExecutable(extractionRoot, distributionFolderName);
        if (extractedBin == null) {
          fail("Gradle archive extracted, but no " + distName
              + "/bin/gradle executable was found. Extracted top-level entries: "
              + listTopLevel(extractionRoot));
        }
        Path finalRoot = wrapperHome.resolve("distribution");
        deleteTree(finalRoot);
        Files.createDirectories(finalRoot);
        // Move the extracted distribution directory intact into the stable cache.
        Path extractedDistRoot = extractedBin.getParent().getParent();
        Path finalDistRoot = finalRoot.resolve(extractedDistRoot.getFileName().toString());
        Files.move(extractedDistRoot, finalDistRoot, StandardCopyOption.REPLACE_EXISTING);
        deleteTree(extractionRoot);
      } catch (Exception e) {
        deleteTree(extractionRoot);
        throw e;
      }
      gradleBin = findGradleExecutable(wrapperHome.resolve("distribution"), distributionFolderName);
      if (gradleBin == null) fail("Gradle executable is still missing after extraction.");
    }

    if (!isWindows()) {
      gradleBin.toFile().setExecutable(true, false);
      Path binDir = gradleBin.getParent();
      try (DirectoryStream<Path> stream = Files.newDirectoryStream(binDir)) {
        for (Path f : stream) {
          if (Files.isRegularFile(f) && !f.getFileName().toString().endsWith(".bat")) {
            f.toFile().setExecutable(true, false);
          }
        }
      }
    }

    List<String> command = new ArrayList<>();
    if (isWindows()) { command.add("cmd.exe"); command.add("/c"); }
    command.add(gradleBin.toString());
    command.addAll(Arrays.asList(args));
    ProcessBuilder pb = new ProcessBuilder(command).directory(project.toFile()).inheritIO();
    pb.environment().put("GRADLE_USER_HOME", gradleUserHome.toString());
    int code = pb.start().waitFor();
    System.exit(code);
  }

  private static void ensureDistribution(URL url, Path zip, String expectedSha) throws Exception {
    boolean needDownload = !Files.isRegularFile(zip);
    if (!needDownload && !expectedSha.isEmpty()) {
      String actual = sha256(zip);
      if (!actual.equals(expectedSha)) {
        Files.deleteIfExists(zip);
        needDownload = true;
      }
    }
    if (needDownload) download(url, zip);
    if (!Files.isRegularFile(zip) || Files.size(zip) < 1024) {
      Files.deleteIfExists(zip);
      fail("Downloaded Gradle distribution is missing or unexpectedly small.");
    }
    if (!expectedSha.isEmpty()) {
      String actual = sha256(zip);
      if (!actual.equals(expectedSha)) {
        Files.deleteIfExists(zip);
        fail("Gradle distribution SHA-256 mismatch. Expected " + expectedSha + ", got " + actual);
      }
    }
    // Validate the central directory before attempting extraction.
    try (ZipFile ignored = new ZipFile(zip.toFile())) {
      // Opening ZipFile verifies that the ZIP central directory is readable.
    } catch (ZipException e) {
      Files.deleteIfExists(zip);
      fail("Downloaded Gradle distribution is not a valid ZIP archive: " + e.getMessage());
    }
  }

  private static Path findGradleExecutable(Path root, String distributionFolderName) throws IOException {
    if (!Files.isDirectory(root)) return null;
    try (java.util.stream.Stream<Path> paths = Files.walk(root, 6)) {
      return paths.filter(p -> Files.isRegularFile(p)
          && p.getFileName().toString().equals(isWindows() ? "gradle.bat" : "gradle")
          && p.getParent() != null
          && p.getParent().getFileName().toString().equals("bin")
          && p.getParent().getParent() != null
          && p.getParent().getParent().getFileName().toString().equals(distributionFolderName))
          .findFirst().orElse(null);
    }
  }

  private static void extractWithZipFile(Path zip, Path destination) throws IOException {
    Path root = destination.toAbsolutePath().normalize();
    try (ZipFile archive = new ZipFile(zip.toFile())) {
      Enumeration<? extends ZipEntry> entries = archive.entries();
      while (entries.hasMoreElements()) {
        ZipEntry entry = entries.nextElement();
        Path out = root.resolve(entry.getName()).normalize();
        if (!out.startsWith(root)) throw new IOException("Unsafe path in Gradle distribution: " + entry.getName());
        if (entry.isDirectory()) {
          Files.createDirectories(out);
          continue;
        }
        Files.createDirectories(out.getParent());
        CRC32 crc = new CRC32();
        long count = 0;
        try (InputStream in = new BufferedInputStream(archive.getInputStream(entry));
             OutputStream os = new BufferedOutputStream(Files.newOutputStream(out))) {
          byte[] buffer = new byte[65536];
          int n;
          while ((n = in.read(buffer)) != -1) {
            os.write(buffer, 0, n);
            crc.update(buffer, 0, n);
            count += n;
          }
        }
        if (entry.getSize() >= 0 && count != entry.getSize()) {
          throw new IOException("Incomplete ZIP entry: " + entry.getName());
        }
        if (entry.getCrc() >= 0 && crc.getValue() != entry.getCrc()) {
          throw new IOException("CRC mismatch while extracting: " + entry.getName());
        }
        if (!isWindows() && entry.getName().matches(".*/bin/[^/]+")) out.toFile().setExecutable(true, false);
      }
    }
  }

  private static String listTopLevel(Path root) throws IOException {
    List<String> names = new ArrayList<>();
    try (DirectoryStream<Path> stream = Files.newDirectoryStream(root)) {
      for (Path p : stream) names.add(p.getFileName().toString());
    }
    return names.toString();
  }

  private static void download(URL url, Path target) throws IOException {
    System.out.println("Downloading pinned Gradle distribution: " + url);
    URLConnection c = url.openConnection();
    c.setConnectTimeout(30000);
    c.setReadTimeout(180000);
    c.setUseCaches(false);
    c.setRequestProperty("User-Agent", "AndroidForge-Gradle-Wrapper/1.0.6");
    Path tmp = target.resolveSibling(target.getFileName() + ".part");
    Files.deleteIfExists(tmp);
    try (InputStream in = new BufferedInputStream(c.getInputStream());
         OutputStream out = new BufferedOutputStream(Files.newOutputStream(tmp))) {
      byte[] b = new byte[65536];
      int n;
      while ((n = in.read(b)) != -1) out.write(b, 0, n);
    } catch (IOException e) {
      Files.deleteIfExists(tmp);
      throw e;
    }
    Files.move(tmp, target, StandardCopyOption.REPLACE_EXISTING);
  }

  private static String sha256(Path file) throws Exception {
    MessageDigest md = MessageDigest.getInstance("SHA-256");
    try (InputStream in = Files.newInputStream(file)) {
      byte[] b = new byte[65536];
      int n;
      while ((n = in.read(b)) != -1) md.update(b, 0, n);
    }
    StringBuilder s = new StringBuilder();
    for (byte b : md.digest()) s.append(String.format(Locale.ROOT, "%02x", b & 0xff));
    return s.toString();
  }

  private static void deleteTree(Path root) throws IOException {
    if (!Files.exists(root)) return;
    try (java.util.stream.Stream<Path> paths = Files.walk(root)) {
      paths.sorted(Comparator.reverseOrder()).forEach(p -> {
        try { Files.deleteIfExists(p); } catch (IOException e) { throw new UncheckedIOException(e); }
      });
    } catch (UncheckedIOException e) { throw e.getCause(); }
  }

  private static String required(Properties p, String key) throws IOException {
    String v = p.getProperty(key);
    if (v == null || v.trim().isEmpty()) throw new IOException("Missing property: " + key);
    return v.trim();
  }
  private static boolean isWindows() {
    return System.getProperty("os.name", "").toLowerCase(Locale.ROOT).contains("win");
  }
  private static void fail(String message) throws IOException { throw new IOException(message); }
}
