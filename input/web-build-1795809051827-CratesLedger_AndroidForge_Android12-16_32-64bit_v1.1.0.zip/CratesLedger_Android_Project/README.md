# Crates Ledger — AndroidForge Project v1.0.8

Android WebView wrapper for the supplied Crates Ledger HTML application.

## Target compatibility
- Android 12 through Android 16 (minSdk 31, compileSdk/targetSdk 36)
- ARM 32-bit (`armeabi-v7a`) and ARM 64-bit (`arm64-v8a`)
- x86 32-bit and x86_64 64-bit
- JDK 17, Android Gradle Plugin 8.13.2, Gradle 8.13

## Build in AndroidForge
1. Upload/extract this project ZIP so the project root contains `settings.gradle`, `build.gradle`, `gradlew`, and `app/`.
2. Ensure AndroidForge uses JDK 17.
3. Run `./gradlew --no-daemon clean assembleDebug` (or `assembleRelease`).
4. The debug APK is produced at `app/build/outputs/apk/debug/`.

The included Linux `gradlew` bootstrapper downloads the official Gradle 8.13
binary distribution, verifies its published SHA-256, extracts it with the
runner's `unzip` utility, then executes it. It deliberately does not use the
runner's older system Gradle 8.9, which is incompatible with AGP 8.13.2.

## This revision
- Restores the full dark-green Crates Ledger header as in the user's confirmed
  reference screenshot (no white/green split banner).
- Fits the full Banana Crates launcher logo inside Android's adaptive-icon safe
  zone so the final letters are not cut off by circular/rounded masks.
- Retains the existing WebView, JSON/CSV backup/restore, PDF, and app behavior.

## Important verification note
This ZIP is a project source package, not an APK. The static checks noted in
`BUILD-STATUS.txt` do not substitute for an AndroidForge build or a physical
Samsung launcher test. Confirm AndroidForge reports a successful build before
installing the resulting APK. Back up existing ledger data before updating.


## UI revision v1.1.0
Opening-page management panel and all opening-page tabs widened by 5 mm total (2.5 mm per side). Top brand banner remains full-viewport width. See WIDTH_REVISION_v1.1.0.txt.
