package com.hasibkhan.suppliersledger;

import android.app.Activity;
import android.app.PrintManager;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.print.PrintDocumentAdapter;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.io.IOException;
import java.io.OutputStream;

public class MainActivity extends Activity {
    private static final int FILE_PICKER_REQUEST = 501;
    private static final int SAVE_FILE_REQUEST = 502;

    private WebView ledgerWebView;
    private ValueCallback<Uri[]> pendingFileCallback;
    private byte[] pendingExportBytes;
    private String pendingExportMime = "application/octet-stream";
    private String pendingExportName = "ledger-export";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        getWindow().setStatusBarColor(Color.rgb(7, 90, 156));
        getWindow().setNavigationBarColor(Color.rgb(7, 26, 42));

        ledgerWebView = new WebView(this);
        ledgerWebView.setBackgroundColor(Color.rgb(243, 247, 244));
        setContentView(ledgerWebView);

        WebSettings webSettings = ledgerWebView.getSettings();
        webSettings.setJavaScriptEnabled(true);
        webSettings.setDomStorageEnabled(true);
        webSettings.setDatabaseEnabled(true);
        webSettings.setAllowFileAccess(true);
        webSettings.setAllowContentAccess(true);
        webSettings.setLoadsImagesAutomatically(true);
        webSettings.setDefaultTextEncodingName("UTF-8");
        webSettings.setSupportZoom(false);
        webSettings.setJavaScriptCanOpenWindowsAutomatically(false);
        webSettings.setSupportMultipleWindows(false);

        ledgerWebView.addJavascriptInterface(new LedgerBridge(), "AndroidLedgerBridge");
        ledgerWebView.setWebChromeClient(new LedgerChrome());
        ledgerWebView.setWebViewClient(new LedgerNavigation());

        if (savedInstanceState != null) {
            ledgerWebView.restoreState(savedInstanceState);
        }
        if (ledgerWebView.getUrl() == null) {
            ledgerWebView.loadUrl("file:///android_asset/index.html");
        }
    }

    private class LedgerNavigation extends WebViewClient {
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
            return openExternalLink(request.getUrl());
        }

        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            return openExternalLink(Uri.parse(url));
        }

        private boolean openExternalLink(Uri uri) {
            String scheme = uri.getScheme();
            if (scheme == null) {
                return true;
            }

            if ("file".equalsIgnoreCase(scheme)
                    && uri.toString().startsWith("file:///android_asset/")) {
                return false;
            }

            if ("http".equalsIgnoreCase(scheme)
                    || "https".equalsIgnoreCase(scheme)
                    || "sms".equalsIgnoreCase(scheme)
                    || "smsto".equalsIgnoreCase(scheme)
                    || "tel".equalsIgnoreCase(scheme)
                    || "mailto".equalsIgnoreCase(scheme)) {
                try {
                    Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                    startActivity(intent);
                } catch (ActivityNotFoundException exception) {
                    Toast.makeText(MainActivity.this,
                            "इस लिंक को खोलने के लिए संबंधित ऐप उपलब्ध नहीं है।",
                            Toast.LENGTH_LONG).show();
                }
                return true;
            }

            return true;
        }
    }

    private class LedgerChrome extends WebChromeClient {
        @Override
        public boolean onShowFileChooser(WebView view,
                                         ValueCallback<Uri[]> fileCallback,
                                         FileChooserParams params) {
            if (pendingFileCallback != null) {
                pendingFileCallback.onReceiveValue(null);
            }

            pendingFileCallback = fileCallback;

            Intent picker = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            picker.addCategory(Intent.CATEGORY_OPENABLE);
            picker.setType("*/*");

            try {
                startActivityForResult(picker, FILE_PICKER_REQUEST);
                return true;
            } catch (ActivityNotFoundException exception) {
                pendingFileCallback = null;
                Toast.makeText(MainActivity.this,
                        "फाइल चुनने की सुविधा उपलब्ध नहीं है।",
                        Toast.LENGTH_LONG).show();
                return false;
            }
        }
    }

    public class LedgerBridge {
        @JavascriptInterface
        public void printHtml(final String html, final String title) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    printLedgerHtml(html, title);
                }
            });
        }

        @JavascriptInterface
        public void saveFile(final String dataUrl,
                             final String fileName,
                             final String mimeType) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    prepareExport(dataUrl, fileName, mimeType);
                }
            });
        }
    }

    private void printLedgerHtml(String html, String requestedTitle) {
        try {
            PrintManager manager =
                    (PrintManager) getSystemService(Context.PRINT_SERVICE);

            if (manager == null) {
                Toast.makeText(this, "Android Print Service उपलब्ध नहीं है।",
                        Toast.LENGTH_LONG).show();
                return;
            }

            final String jobTitle;
            if (requestedTitle == null || requestedTitle.trim().length() == 0) {
                jobTitle = "Suppliers Ledger";
            } else {
                jobTitle = requestedTitle;
            }

            final WebView printView = new WebView(this);
            printView.getSettings().setJavaScriptEnabled(false);
            printView.getSettings().setDefaultTextEncodingName("UTF-8");

            printView.setWebViewClient(new WebViewClient() {
                @Override
                public void onPageFinished(WebView view, String url) {
                    PrintDocumentAdapter adapter =
                            view.createPrintDocumentAdapter(jobTitle);
                    manager.print(jobTitle, adapter, null);
                }
            });

            printView.loadDataWithBaseURL(
                    "file:///android_asset/",
                    html,
                    "text/html",
                    "UTF-8",
                    null
            );
        } catch (RuntimeException exception) {
            Toast.makeText(this,
                    "PDF / Print शुरू नहीं हो सका। कृपया दोबारा प्रयास करें।",
                    Toast.LENGTH_LONG).show();
        }
    }

    private void prepareExport(String dataUrl, String fileName, String mimeType) {
        try {
            if (dataUrl == null) {
                throw new IllegalArgumentException("Export data is empty");
            }

            int commaPosition = dataUrl.indexOf(',');
            if (commaPosition < 0) {
                throw new IllegalArgumentException("Invalid export data");
            }

            String encodedData = dataUrl.substring(commaPosition + 1);
            pendingExportBytes = Base64.decode(encodedData, Base64.DEFAULT);

            if (fileName == null || fileName.trim().length() == 0) {
                pendingExportName = "ledger-export";
            } else {
                pendingExportName = fileName.replaceAll("[\\\\/:*?\"<>|]", "_");
            }

            if (mimeType == null || mimeType.trim().length() == 0) {
                pendingExportMime = "application/octet-stream";
            } else {
                pendingExportMime = mimeType;
            }

            Intent createFile = new Intent(Intent.ACTION_CREATE_DOCUMENT);
            createFile.addCategory(Intent.CATEGORY_OPENABLE);
            createFile.setType(pendingExportMime);
            createFile.putExtra(Intent.EXTRA_TITLE, pendingExportName);
            startActivityForResult(createFile, SAVE_FILE_REQUEST);

        } catch (RuntimeException exception) {
            pendingExportBytes = null;
            Toast.makeText(this, "फाइल सेव करने की तैयारी विफल हुई।",
                    Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == FILE_PICKER_REQUEST) {
            if (pendingFileCallback != null) {
                Uri[] selectedFiles = null;
                if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                    selectedFiles = new Uri[]{data.getData()};
                }
                pendingFileCallback.onReceiveValue(selectedFiles);
                pendingFileCallback = null;
            }
            return;
        }

        if (requestCode == SAVE_FILE_REQUEST) {
            if (resultCode == RESULT_OK
                    && data != null
                    && data.getData() != null
                    && pendingExportBytes != null) {
                OutputStream output = null;
                try {
                    output = getContentResolver().openOutputStream(data.getData());
                    if (output == null) {
                        throw new IOException("Could not open selected file");
                    }
                    output.write(pendingExportBytes);
                    output.flush();
                    Toast.makeText(this, "फाइल सफलतापूर्वक सेव हो गई।",
                            Toast.LENGTH_LONG).show();
                } catch (IOException exception) {
                    Toast.makeText(this, "फाइल सेव नहीं हो सकी।",
                            Toast.LENGTH_LONG).show();
                } finally {
                    if (output != null) {
                        try {
                            output.close();
                        } catch (IOException ignored) {
                        }
                    }
                }
            }
            pendingExportBytes = null;
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle state) {
        if (ledgerWebView != null) {
            ledgerWebView.saveState(state);
        }
        super.onSaveInstanceState(state);
    }

    @Override
    public void onBackPressed() {
        if (ledgerWebView != null && ledgerWebView.canGoBack()) {
            ledgerWebView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        if (pendingFileCallback != null) {
            pendingFileCallback.onReceiveValue(null);
            pendingFileCallback = null;
        }

        if (ledgerWebView != null) {
            ledgerWebView.stopLoading();
            ledgerWebView.destroy();
            ledgerWebView = null;
        }

        super.onDestroy();
    }
}
