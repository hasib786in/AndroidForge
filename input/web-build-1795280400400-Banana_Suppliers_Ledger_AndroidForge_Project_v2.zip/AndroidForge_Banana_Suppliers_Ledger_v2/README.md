# 🍌Suppliers Ledger — AndroidForge Project ZIP (v2)

## App identity
- App display name: `🍌Suppliers Ledger`
- Application ID: `com.hasibkhan.suppliersledger`
- Version: `1.0.1`
- Launcher icon: supplied Banana Suppliers Ledger artwork

## AndroidForge-compatible build configuration
- Minimum SDK: 31 (Android 12)
- Compile SDK: 34
- Target SDK: 34
- Android Gradle Plugin: 8.7.3
- Java source/target: 1.8
- Build JDK: 17
- Gradle: AndroidForge preinstalled system Gradle 8.9 (no incomplete wrapper included)

AndroidForge's published prebuilt build image includes Android SDK platforms through API 34, Build Tools 34.0.0, JDK 17 and system Gradle 8.9. AGP 8.7.3 is compatible with Gradle 8.9 and JDK 17. This project deliberately uses compileSdk 34 to match the preinstalled platform and avoid an SDK download step. It remains installable on Android 12–16; targetSdk 34 means it does not opt into all newer target-SDK-only behavior changes.

## CPU architecture
The app is Java + Android WebView only. It includes no ABI-specific native `.so` files, so a single APK is architecture-neutral and supports compatible 32-bit ARM and 64-bit ARM Android devices.

## Included app functionality
- Original ledger HTML and existing JavaScript business logic.
- Local WebView storage.
- Native Android print bridge for ledger reports.
- Android document picker for file imports.
- Android Save As picker for exported files.
- External intents for WhatsApp, SMS, phone and web links.
- Original supplied launcher artwork and app label.

## AndroidForge upload
Upload this ZIP in AndroidForge. Choose Android and Debug (or Auto) for the first build. The project intentionally omits an incomplete Gradle wrapper; AndroidForge's documented build image provides system Gradle 8.9 and can use it when a project has no wrapper.

## Validation / limitations
- ZIP integrity, project file structure, XML well-formedness and embedded JavaScript syntax were checked before delivery.
- The Java source was simplified to Java 8 syntax and uses only stable Android APIs available by API 31.
- This environment does not contain the Android SDK/Gradle build environment, so a real `assembleDebug` build has not been executed here.
- A successful APK build still needs AndroidForge's build logs to confirm. If it fails, download the AndroidForge-logs artifact and share the first `error:` line; do not regenerate another project blindly.
- WebView localStorage belongs to this app installation. Browser HTML data is not automatically migrated; export a JSON backup from the existing HTML app and import it into the APK.
- Excel import/export uses the existing SheetJS CDN dependency and therefore needs internet access.
