package com.hasibkhan.suppliersledger;

import android.app.Activity;
import android.app.PrintManager;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.print.PrintDocumentAdapter;
import android.provider.DocumentsContract;
import android.view.WindowInsets;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import android.util.Base64;

import java.io.OutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {
    private static final int REQUEST_FILE_PICKER = 4101;
    private static final int REQUEST_SAVE_FILE = 4102;

    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;
    private byte[] pendingSaveBytes;
    private String pendingSaveName = "ledger-export";
    private String pendingSaveMime = "application/octet-stream";
    private final List<WebView> printWebViews = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(7, 90, 156));
        getWindow().setNavigationBarColor(Color.rgb(7, 26, 42));

        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(243, 247, 244));
        setContentView(webView);

        // Target SDK 36 uses edge-to-edge system bars on Android 15/16.
        if (Build.VERSION.SDK_INT >= 35) {
            webView.setOnApplyWindowInsetsListener((view, insets) -> {
                android.graphics.Insets bars = insets.getInsets(WindowInsets.Type.systemBars());
                view.setPadding(0, bars.top, 0, bars.bottom);
                return insets;
            });
        }

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setSupportMultipleWindows(false);
        settings.setLoadsImagesAutomatically(true);
        settings.setDefaultTextEncodingName("UTF-8");
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setSupportZoom(false);

        webView.addJavascriptInterface(new AndroidLedgerBridge(), "AndroidLedgerBridge");
        webView.setWebChromeClient(new LedgerChromeClient());
        webView.setWebViewClient(new LedgerWebViewClient());

        if (savedInstanceState != null && webView.restoreState(savedInstanceState) != null) {
            // Restored WebView state retains the local document session.
        } else {
            webView.loadUrl("file:///android_asset/index.html");
        }
    }

    private class LedgerWebViewClient extends WebViewClient {
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
            return handleExternalUrl(request.getUrl());
        }

        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            return handleExternalUrl(Uri.parse(url));
        }

        private boolean handleExternalUrl(Uri uri) {
            String scheme = uri.getScheme() == null ? "" : uri.getScheme().toLowerCase();
            String url = uri.toString();
            if ("file".equals(scheme) && url.startsWith("file:///android_asset/")) {
                return false;
            }
            if ("http".equals(scheme) || "https".equals(scheme)
                    || "sms".equals(scheme) || "smsto".equals(scheme)
                    || "tel".equals(scheme) || "mailto".equals(scheme)) {
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, uri));
                } catch (ActivityNotFoundException ex) {
                    Toast.makeText(MainActivity.this,
                            "इस लिंक को खोलने के लिए संबंधित ऐप उपलब्ध नहीं है।",
                            Toast.LENGTH_LONG).show();
                }
                return true;
            }
            return true;
        }
    }

    private class LedgerChromeClient extends WebChromeClient {
        @Override
        public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback,
                                         FileChooserParams params) {
            if (filePathCallback != null) filePathCallback.onReceiveValue(null);
            filePathCallback = callback;
            Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.setType("*/*");
            try {
                startActivityForResult(intent, REQUEST_FILE_PICKER);
            } catch (ActivityNotFoundException ex) {
                filePathCallback = null;
                Toast.makeText(MainActivity.this, "फाइल चुनने की सुविधा उपलब्ध नहीं है।",
                        Toast.LENGTH_LONG).show();
                return false;
            }
            return true;
        }
    }

    public class AndroidLedgerBridge {
        @JavascriptInterface
        public void printHtml(final String html, final String jobName) {
            runOnUiThread(() -> startNativePrint(html, jobName));
        }

        @JavascriptInterface
        public void saveFile(final String dataUrl, final String fileName, final String mimeType) {
            runOnUiThread(() -> prepareSaveFile(dataUrl, fileName, mimeType));
        }
    }

    private void startNativePrint(String html, String jobName) {
        try {
            PrintManager printManager = (PrintManager) getSystemService(PRINT_SERVICE);
            if (printManager == null) {
                Toast.makeText(this, "Android Print Service उपलब्ध नहीं है।",
                        Toast.LENGTH_LONG).show();
                return;
            }
            final String title = (jobName == null || jobName.trim().isEmpty())
                    ? "Suppliers Ledger" : jobName;
            WebView printWebView = new WebView(this);
            printWebViews.add(printWebView);
            printWebView.getSettings().setJavaScriptEnabled(false);
            printWebView.getSettings().setDefaultTextEncodingName("UTF-8");
            printWebView.setWebViewClient(new WebViewClient() {
                @Override
                public void onPageFinished(WebView view, String url) {
                    PrintDocumentAdapter adapter = view.createPrintDocumentAdapter(title);
                    printManager.print(title, adapter, null);
                }
            });
            printWebView.loadDataWithBaseURL(
                    "file:///android_asset/", html, "text/html", "UTF-8", null);
        } catch (Exception ex) {
            Toast.makeText(this, "PDF / Print शुरू नहीं हो सका। कृपया दोबारा प्रयास करें।",
                    Toast.LENGTH_LONG).show();
        }
    }

    private void prepareSaveFile(String dataUrl, String fileName, String mimeType) {
        try {
            int comma = dataUrl.indexOf(',');
            if (comma < 0) throw new IllegalArgumentException("Invalid data URL");
            pendingSaveBytes = Base64.decode(dataUrl.substring(comma + 1), Base64.DEFAULT);
            pendingSaveName = (fileName == null || fileName.trim().isEmpty())
                    ? "ledger-export" : fileName.replaceAll("[\\\\/:*?\"<>|]", "_");
            pendingSaveMime = (mimeType == null || mimeType.trim().isEmpty())
                    ? "application/octet-stream" : mimeType;

            Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.setType(pendingSaveMime);
            intent.putExtra(Intent.EXTRA_TITLE, pendingSaveName);
            startActivityForResult(intent, REQUEST_SAVE_FILE);
        } catch (Exception ex) {
            Toast.makeText(this, "फाइल सेव करने की तैयारी विफल हुई।",
                    Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_FILE_PICKER) {
            if (filePathCallback != null) {
                Uri[] result = (resultCode == RESULT_OK && data != null && data.getData() != null)
                        ? new Uri[]{data.getData()} : null;
                filePathCallback.onReceiveValue(result);
                filePathCallback = null;
            }
        } else if (requestCode == REQUEST_SAVE_FILE) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null
                    && pendingSaveBytes != null) {
                try (OutputStream output = getContentResolver().openOutputStream(data.getData())) {
                    if (output == null) throw new IOException("Unable to open destination");
                    output.write(pendingSaveBytes);
                    output.flush();
                    Toast.makeText(this, "फाइल सफलतापूर्वक सेव हो गई।", Toast.LENGTH_LONG).show();
                } catch (Exception ex) {
                    Toast.makeText(this, "फाइल सेव नहीं हो सकी।", Toast.LENGTH_LONG).show();
                }
            }
            pendingSaveBytes = null;
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        if (webView != null) webView.saveState(outState);
        super.onSaveInstanceState(outState);
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (filePathCallback != null) {
            filePathCallback.onReceiveValue(null);
            filePathCallback = null;
        }
        for (WebView printView : printWebViews) {
            try { printView.destroy(); } catch (Exception ignored) { }
        }
        printWebViews.clear();
        if (webView != null) {
            webView.stopLoading();
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
