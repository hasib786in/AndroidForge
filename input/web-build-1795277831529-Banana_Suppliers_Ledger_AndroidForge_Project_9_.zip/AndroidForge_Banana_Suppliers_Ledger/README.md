# 🍌Suppliers Ledger — AndroidForge Source Project

## App identity
- Display name: `🍌Suppliers Ledger`
- Application ID: `com.hasibkhan.suppliersledger`
- Version: `1.0.0`
- Launcher icon: supplied Banana Suppliers Ledger artwork

## Android compatibility
- Install minimum: Android 12 (API 31)
- Verified target behavior baseline: API 35
- Compatible runtime range requested: Android 12, 13, 14, 15 and 16
- Compile SDK / Target SDK: 35
- Android Gradle Plugin: 8.7.3
- Gradle: 8.9
- JDK: 17

**Why target API 35 instead of 36:** AndroidForge's currently published toolchain rules map AGP 8.7.x to Gradle 8.9, and its prebuilt image already includes Gradle 8.9. AGP 8.7 officially supports up to API 35. Pinning this supported combination avoids asking AndroidForge's current builder to run AGP 8.10 with its incompatible Gradle 8.9 fallback. An app targeting API 35 remains installable and runnable on Android 16; it simply does not opt into every behavior that requires targeting API 36. The Activity includes system-bar inset handling for Android 15+.

## CPU architecture
This is a Java-only Android WebView app and contains no ABI-specific native `.so` libraries. One architecture-neutral APK can run on supported 32-bit ARM (`armeabi-v7a`) and 64-bit ARM (`arm64-v8a`) Android devices. Since there are no native binaries, separate ABI splits are not needed.

## Android integration
- Original ledger HTML is packaged at `app/src/main/assets/index.html`.
- WebView JavaScript and DOM storage are enabled for the existing localStorage data model.
- File imports use Android's document picker.
- Blob exports (JSON/CSV/XLSX/HTML) are passed to Android's Save As document picker.
- Financial, Crates and backup reports use Android's native PrintManager bridge.
- WhatsApp/SMS and external URLs are dispatched to Android intents.
- The original ledger business logic is retained; Android-specific changes are integration adapters.

## AndroidForge
Upload this ZIP as the Android source ZIP. For the first run, select Android and Debug/Auto. AndroidForge detects the Gradle project and uses its published AGP 8.7 -> Gradle 8.9 toolchain mapping.

## Important validation notes
1. This ZIP is Android source code, not an APK.
2. The HTML currently loads SheetJS 0.18.5 from jsDelivr. Excel import/export therefore needs internet access; other ledger data and localStorage do not need a remote server.
3. WebView localStorage is private to this installed app. Existing records saved in a separate browser or HTML viewer are not automatically migrated. Export a JSON backup from the old ledger and restore it inside the APK if those records must be carried forward.
4. The project has passed static checks for inline JavaScript syntax, XML well-formedness and ZIP integrity in this environment. A real AndroidForge build and physical-device tests are still required for Android 12–16 and both ARM device classes.
5. AndroidForge's default output may be a debug APK. A signed release APK for distribution requires a private signing key configured separately.
