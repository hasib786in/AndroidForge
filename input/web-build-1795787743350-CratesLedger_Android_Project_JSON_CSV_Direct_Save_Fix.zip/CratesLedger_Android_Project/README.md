# Crates Ledger — Android project

This project packages the supplied Crates Ledger HTML application inside a native Android WebView shell.

## Project configuration

- Minimum Android version: Android 12 (API 31)
- Compile SDK: Android 15 (API 35)
- Target SDK: Android 14 (API 34)
- Android Gradle Plugin: 8.7.3
- Gradle: 8.9 (standalone)
- JDK: 17
- ARM 32-bit: `armeabi-v7a`
- ARM 64-bit: `arm64-v8a`

`minSdk 31` permits installation on Android 12 and later, including Android 16 devices. The app is compiled against API 35 and targets API 34. Target 34 is intentional: it avoids Android 15's target-35 edge-to-edge enforcement, which had allowed the WebView header to sit underneath the status bar. The app still supports Android 12+ by minSdk.

AGP 8.7.3 is paired with Gradle 8.9 and JDK 17. Do not upgrade one of these independently.

## Build with GitHub Actions / AndroidForge

The included workflow installs Android SDK Platform 35 and Build Tools 35.0.0, installs standalone Gradle 8.9, and runs:

```bash
gradle --no-daemon clean assembleDebug
```

The workflow deliberately uses standalone Gradle rather than a Gradle Wrapper. The `gradle-wrapper.properties` file records the same 8.9 distribution for tools that inspect it, but this archive does not include a wrapper JAR or launcher scripts. AndroidForge/GitHub builds must use the configured standalone Gradle 8.9 command; this is not a complete Gradle Wrapper distribution.

To build in GitHub Actions, push the project to the repository's `main` branch or manually run **Build Crates Ledger APK** from the Actions tab. The generated debug APK is uploaded as the `CratesLedger-Android-APK` artifact.

Expected APK path: `app/build/outputs/apk/debug/app-debug.apk`

## Included Android integrations

- Persistent WebView DOM storage for the existing `localStorage` ledger database
- Native file picker for JSON, CSV and Excel restore inputs
- Native save-to-Downloads handling for JSON, CSV and Excel Blob exports (the JavaScript bridge is publicly exposed; MediaStore files are published only after a successful write)
- Android `PrintManager` integration for ledger PDF/print flows
- External hand-off for WhatsApp and SMS links
- Android system back navigation
- Cleanup of the temporary print WebView when a print job finishes or the Activity is destroyed

## Offline-use limitation

The main ledger, JSON backup/restore and CSV backup/restore are implemented locally. The SheetJS 0.18.5 library is bundled in `app/src/main/assets/xlsx.full.min.js` and loaded from the app's local assets. Excel import/export no longer depends on jsDelivr or an internet connection.

## Data safety

- The original customer ledger calculations and business logic have not been changed as part of this packaging work.
- App data is stored in the app's WebView storage. Uninstalling the app or clearing its storage removes local records. Export a JSON backup regularly.
- The current build configuration produces an unsigned debug APK. A signed release APK/AAB requires a private signing key and secure signing configuration.


## Android home-screen viewport matching

The native WebView now keeps content within the system-bar-safe area instead of drawing edge-to-edge. The Android-only home-screen CSS uses separate mobile control heights measured from the supplied HTML browser screenshot, rather than viewport-height-based sizing that made the installed APK buttons taller. The HTML file opened in a browser is unchanged by these APK-only CSS selectors.


## JSON / CSV backup downloads on Android

The JSON and CSV backup buttons call the native `AndroidLedgerBridge.saveTextFile`
method directly with UTF-8 content and the correct MIME type. This avoids relying
on synthetic Blob-download click interception for these two backup actions.
The native app publishes each file in `Downloads/Crates Ledger` only after the
MediaStore write completes. Browser use retains a Blob-download fallback.
