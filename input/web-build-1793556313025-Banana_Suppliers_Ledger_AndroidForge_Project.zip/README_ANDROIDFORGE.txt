Banana Suppliers Ledger - AndroidForge project

Import this ZIP into AndroidForge as an Android source project.

App:
- Name: Banana Suppliers Ledger
- Package: com.hasibkhan.bananasuppliersledger
- Min Android: 6.0 (API 23)
- Compile/Target SDK: 35
- Java: 17
- App type: Native Android WebView wrapper around the supplied HTML ledger.

Build:
1. Upload this ZIP to your AndroidForge web UI.
2. Select Android and Debug (first build recommended).
3. Start Build APK and download the generated APK artifact.

Notes:
- The HTML app is bundled at app/src/main/assets/index.html.
- JavaScript and DOM storage are enabled so the ledger UI and localStorage data work in WebView.
- Internet permission is included because the HTML application uses an external SheetJS CDN for spreadsheet features.
- WhatsApp/SMS actions are handed to Android apps through URL intents.
- Imported files can be selected through the Android file picker.
- This ZIP is the Android project source, not a prebuilt APK.
