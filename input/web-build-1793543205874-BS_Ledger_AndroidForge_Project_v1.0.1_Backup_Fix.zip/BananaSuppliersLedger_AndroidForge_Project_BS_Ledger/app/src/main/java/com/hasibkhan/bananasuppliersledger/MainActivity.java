package com.hasibkhan.bananasuppliersledger;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.io.OutputStream;

public class MainActivity extends Activity {
    private static final int REQUEST_CREATE_FILE = 4101;
    private static final int REQUEST_OPEN_FILE = 4102;
    private WebView webView;
    private ValueCallback<Uri[]> fileChooserCallback;
    private byte[] pendingFileBytes;
    private String pendingMimeType = "application/octet-stream";
    private String pendingFileName = "backup";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);

        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setAllowFileAccess(true);
        webView.getSettings().setAllowContentAccess(true);
        webView.getSettings().setSupportMultipleWindows(false);
        webView.addJavascriptInterface(new AndroidBridge(), "AndroidBridge");

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback,
                                             FileChooserParams params) {
                if (fileChooserCallback != null) fileChooserCallback.onReceiveValue(null);
                fileChooserCallback = callback;
                Intent intent = params.createIntent();
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                try {
                    startActivityForResult(intent, REQUEST_OPEN_FILE);
                } catch (ActivityNotFoundException e) {
                    fileChooserCallback = null;
                    callback.onReceiveValue(null);
                    Toast.makeText(MainActivity.this, "फ़ाइल चुनने के लिए कोई ऐप उपलब्ध नहीं है।", Toast.LENGTH_LONG).show();
                }
                return true;
            }
        });

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return handleUrl(request.getUrl().toString());
            }
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return handleUrl(url);
            }
        });
        webView.loadUrl("file:///android_asset/index.html");
    }

    private boolean handleUrl(String url) {
        if (url == null) return false;
        if (url.startsWith("file:///android_asset/")) return false;
        if (url.startsWith("http://") || url.startsWith("https://")
                || url.startsWith("sms:") || url.startsWith("smsto:")
                || url.startsWith("tel:") || url.startsWith("mailto:")
                || url.startsWith("whatsapp:")) {
            try {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
            } catch (ActivityNotFoundException e) {
                Toast.makeText(this, "इस लिंक को खोलने के लिए उपयुक्त ऐप उपलब्ध नहीं है।", Toast.LENGTH_LONG).show();
            }
            return true;
        }
        return false;
    }

    private void requestSaveFile(String fileName, String mimeType, String base64Data) {
        try {
            pendingFileName = (fileName == null || fileName.trim().isEmpty()) ? "ledger-backup" : fileName;
            pendingMimeType = (mimeType == null || mimeType.trim().isEmpty()) ? "application/octet-stream" : mimeType;
            pendingFileBytes = Base64.decode(base64Data, Base64.DEFAULT);
            Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.setType(pendingMimeType);
            intent.putExtra(Intent.EXTRA_TITLE, pendingFileName);
            startActivityForResult(intent, REQUEST_CREATE_FILE);
        } catch (Exception e) {
            pendingFileBytes = null;
            Toast.makeText(this, "फ़ाइल तैयार नहीं हो सकी। दोबारा प्रयास करें।", Toast.LENGTH_LONG).show();
        }
    }

    private void startPrint() {
        try {
            PrintManager printManager = (PrintManager) getSystemService(PRINT_SERVICE);
            if (printManager == null) throw new IllegalStateException("Print service unavailable");
            String jobName = "B_S_Ledger_Report";
            printManager.print(jobName, webView.createPrintDocumentAdapter(jobName),
                    new PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                            .setResolution(new PrintAttributes.Resolution("pdf", "PDF", 300, 300))
                            .setMinMargins(PrintAttributes.Margins.NO_MARGINS).build());
        } catch (Exception e) {
            Toast.makeText(this, "PDF / प्रिंट सेवा उपलब्ध नहीं है।", Toast.LENGTH_LONG).show();
        }
    }

    private class AndroidBridge {
        @JavascriptInterface
        public void showMessage(String message) {
            runOnUiThread(() -> Toast.makeText(MainActivity.this, message, Toast.LENGTH_LONG).show());
        }
        @JavascriptInterface
        public void saveFile(String fileName, String mimeType, String base64Data) {
            runOnUiThread(() -> requestSaveFile(fileName, mimeType, base64Data));
        }
        @JavascriptInterface
        public void printPage() {
            runOnUiThread(() -> startPrint());
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_OPEN_FILE) {
            if (fileChooserCallback != null) {
                Uri[] result = (resultCode == RESULT_OK && data != null && data.getData() != null)
                        ? new Uri[]{data.getData()} : null;
                fileChooserCallback.onReceiveValue(result);
                fileChooserCallback = null;
            }
        } else if (requestCode == REQUEST_CREATE_FILE) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null && pendingFileBytes != null) {
                try (OutputStream output = getContentResolver().openOutputStream(data.getData())) {
                    if (output == null) throw new IllegalStateException("Unable to open output stream");
                    output.write(pendingFileBytes);
                    output.flush();
                    Toast.makeText(this, "फ़ाइल सफलतापूर्वक सेव हो गई।", Toast.LENGTH_LONG).show();
                } catch (Exception e) {
                    Toast.makeText(this, "फ़ाइल सेव नहीं हो सकी। दूसरी जगह चुनकर प्रयास करें।", Toast.LENGTH_LONG).show();
                }
            }
            pendingFileBytes = null;
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
