BANANA SUPPLIERS LEDGER — ANDROIDFORGE PROJECT

This is a native Android WebView wrapper around the approved Banana Suppliers Ledger HTML app.

PROJECT ROOT
- settings.gradle
- build.gradle
- app/build.gradle
- app/src/main/AndroidManifest.xml
- app/src/main/assets/index.html
- app/src/main/java/com/hasibkhan/bananasuppliersledger/MainActivity.java

ANDROIDFORGE
1. Upload this ZIP to the AndroidForge web UI:
   https://professional-x.github.io/AndroidForge/
2. Select Android.
3. Select build variant: debug (first test build recommended).
4. Start Build and download the APK artifact after GitHub Actions completes.

APP CONFIGURATION
- App name: Banana Suppliers Ledger
- Package: com.hasibkhan.bananasuppliersledger
- Version: 1.0.0 (versionCode 1)
- Minimum Android: 6.0 (API 23)
- Compile/Target SDK: 35

NOTES
- The existing HTML app is bundled locally; it does not need a web server to open.
- JavaScript and WebView DOM storage are enabled for the app's existing features and localStorage data.
- WhatsApp/SMS and ordinary web links are handed to Android to open in the relevant app/browser.
- This ZIP is Android source code, not an APK. AndroidForge must run the build before an APK exists.
- Validate the resulting APK on the target phone before using it for business-critical records.


Launcher branding update:
- Installed app display name: B. S Ledger
- Launcher icon: Banana Suppliers Ledger artwork
- Launcher icon PNGs are included in app/src/main/res/mipmap-*.


BACKUP / RESTORE ANDROID FIX — VERSION 1.0.1
- JSON, CSV and Excel exports now use Android's system Save File picker (Storage Access Framework).
- JSON, CSV and Excel restore inputs open Android's system file picker.
- PDF / Print Report invokes Android Print Framework; choose Save as PDF in the print dialog.
- Internet permission is enabled for the existing SheetJS/XLSX library loaded from jsDelivr. Excel generation therefore requires internet access unless the library is bundled locally.
- App data remains in this app's WebView local storage. Export a backup before clearing app data or uninstalling.
- Package name is unchanged; versionCode is 2 and versionName is 1.0.1 so the APK can update the existing installation.

TEST CHECKLIST AFTER BUILD
1. JSON Backup: save the .json file using the Android Save picker.
2. JSON Restore: select that saved .json file and confirm restore.
3. CSV Download / Restore: export then re-import the CSV.
4. Excel Download / Restore: with internet available, export .xlsx then re-import it.
5. PDF / Print Report: choose Save as PDF from Android's print dialog.
