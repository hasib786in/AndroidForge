package com.hasib.cratesledger;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.os.ParcelFileDescriptor;
import android.os.Environment;
import android.provider.MediaStore;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintManager;
import android.print.PageRange;
import android.util.Base64;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.Locale;
import java.util.HashSet;
import java.util.Set;

public class MainActivity extends Activity {
    private WebView webView;
    private ValueCallback<Uri[]> fileChooserCallback;
    private static final int FILE_CHOOSER_REQUEST = 4102;
    private final Set<WebView> activePrintWebViews = new HashSet<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        webView = new WebView(this);
        webView.setBackgroundColor(Color.WHITE);
        setContentView(webView);
        configureSystemBars();

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setSupportZoom(true);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setSupportMultipleWindows(false);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            settings.setSafeBrowsingEnabled(true);
        }

        webView.addJavascriptInterface(new AndroidLedgerBridge(), "AndroidLedgerBridge");
        webView.setWebViewClient(new LedgerWebViewClient());
        webView.setWebChromeClient(new LedgerChromeClient());

        if (savedInstanceState != null) {
            webView.restoreState(savedInstanceState);
        } else {
            webView.loadUrl("file:///android_asset/index.html");
        }
    }

    private void configureSystemBars() {
        Window window = getWindow();
        window.setStatusBarColor(Color.WHITE);
        window.setNavigationBarColor(Color.WHITE);
        // Explicitly clear fullscreen/no-limits flags so the HTML header cannot
        // start underneath the status bar on devices with inherited UI flags.
        window.clearFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN |
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        );
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            window.setDecorFitsSystemWindows(true);
            WindowInsetsController controller = window.getInsetsController();
            if (controller != null) {
                controller.setSystemBarsAppearance(
                    WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS |
                    WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS,
                    WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS |
                    WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS
                );
                // Keep both bars visible; the content area is then inset by Android.
                controller.show(
                    WindowInsets.Type.statusBars() | WindowInsets.Type.navigationBars()
                );
            }
            webView.setPadding(0, 0, 0, 0);
        } else {
            window.getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR |
                View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
            );
        }
    }

    private class LedgerWebViewClient extends WebViewClient {
        @Override
        public void onPageFinished(WebView view, String url) {
            if (url != null && url.startsWith("file:///android_asset/")) {
                view.evaluateJavascript(AndroidShim.SCRIPT, null);
            }
            super.onPageFinished(view, url);
        }

        @Override
        public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
            return routeUrl(request.getUrl());
        }

        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            return routeUrl(Uri.parse(url));
        }

        private boolean routeUrl(Uri uri) {
            String scheme = uri.getScheme() == null ? "" : uri.getScheme().toLowerCase(Locale.ROOT);
            String host = uri.getHost() == null ? "" : uri.getHost().toLowerCase(Locale.ROOT);

            if ("file".equals(scheme) && uri.getPath() != null &&
                uri.getPath().startsWith("/android_asset/")) {
                return false;
            }
            if ("https".equals(scheme) && ("wa.me".equals(host) || host.endsWith("whatsapp.com"))) {
                return openExternal(new Intent(Intent.ACTION_VIEW, uri));
            }
            if ("sms".equals(scheme) || "smsto".equals(scheme)) {
                return openExternal(new Intent(Intent.ACTION_SENDTO, uri));
            }
            if ("tel".equals(scheme) || "mailto".equals(scheme)) {
                return openExternal(new Intent(Intent.ACTION_VIEW, uri));
            }
            if ("http".equals(scheme) || "https".equals(scheme)) {
                return openExternal(new Intent(Intent.ACTION_VIEW, uri));
            }
            return true;
        }

        private boolean openExternal(Intent intent) {
            try {
                startActivity(intent);
            } catch (ActivityNotFoundException e) {
                Toast.makeText(MainActivity.this, "इस लिंक को खोलने के लिए कोई ऐप उपलब्ध नहीं है।", Toast.LENGTH_LONG).show();
            }
            return true;
        }
    }

    private class LedgerChromeClient extends WebChromeClient {
        @Override
        public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback,
                                         FileChooserParams params) {
            if (fileChooserCallback != null) fileChooserCallback.onReceiveValue(null);
            fileChooserCallback = callback;
            Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.setType("*/*");
            String[] accept = params.getAcceptTypes();
            if (accept != null && accept.length > 0) {
                intent.putExtra(Intent.EXTRA_MIME_TYPES, accept);
            }
            intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, params.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE);
            try {
                startActivityForResult(intent, FILE_CHOOSER_REQUEST);
            } catch (ActivityNotFoundException e) {
                fileChooserCallback = null;
                callback.onReceiveValue(null);
                Toast.makeText(MainActivity.this, "फाइल चुनने वाला ऐप उपलब्ध नहीं है।", Toast.LENGTH_LONG).show();
            }
            return true;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER_REQUEST && fileChooserCallback != null) {
            Uri[] results = null;
            if (resultCode == RESULT_OK && data != null) {
                if (data.getClipData() != null) {
                    int count = data.getClipData().getItemCount();
                    results = new Uri[count];
                    for (int i = 0; i < count; i++) results[i] = data.getClipData().getItemAt(i).getUri();
                } else if (data.getData() != null) {
                    results = new Uri[]{data.getData()};
                }
            }
            fileChooserCallback.onReceiveValue(results);
            fileChooserCallback = null;
        }
    }

    private void releasePrintWebView(WebView view) {
        if (view == null) return;
        activePrintWebViews.remove(view);
        try {
            view.stopLoading();
            view.loadUrl("about:blank");
            view.setWebViewClient(null);
            view.setWebChromeClient(null);
            view.removeAllViews();
            view.destroy();
        } catch (Exception ignored) {
            // Cleanup is best-effort; the print job may already have released it.
        }
    }

    public final class AndroidLedgerBridge {
        @JavascriptInterface
        public void saveTextFile(String fileName, String content, String mimeType) {
            try {
                if (content == null) throw new IllegalArgumentException("फाइल का डेटा खाली है।");
                byte[] bytes = content.getBytes(StandardCharsets.UTF_8);
                saveBytesToDownloads(fileName, bytes, mimeType);
            } catch (Exception e) {
                showDownloadError(e);
            }
        }

        @JavascriptInterface
        public void saveBase64File(String fileName, String dataUrl) {
            try {
                if (dataUrl == null) throw new IllegalArgumentException("फाइल डेटा उपलब्ध नहीं है।");
                int comma = dataUrl.indexOf(',');
                if (comma < 0) throw new IllegalArgumentException("Invalid file data");
                byte[] bytes = Base64.decode(dataUrl.substring(comma + 1), Base64.DEFAULT);
                saveBytesToDownloads(fileName, bytes, null);
            } catch (Exception e) {
                showDownloadError(e);
            }
        }

        private void saveBytesToDownloads(String fileName, byte[] bytes, String requestedMime) throws Exception {
            String safeName = fileName == null || fileName.trim().isEmpty()
                ? "CratesLedger-export" : fileName.replaceAll("[\\\\/:*?\\\"<>|]", "_");
            String lower = safeName.toLowerCase(Locale.ROOT);
            String mime = requestedMime == null || requestedMime.trim().isEmpty()
                ? "application/octet-stream" : requestedMime;
            if (lower.endsWith(".json")) mime = "application/json";
            else if (lower.endsWith(".csv")) mime = "text/csv";
            else if (lower.endsWith(".xlsx")) mime = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";

            ContentValues values = new ContentValues();
            values.put(MediaStore.Downloads.DISPLAY_NAME, safeName);
            values.put(MediaStore.Downloads.MIME_TYPE, mime);
            values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Crates Ledger");
            values.put(MediaStore.Downloads.IS_PENDING, 1);

            Uri collection = MediaStore.Downloads.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY);
            Uri fileUri = getContentResolver().insert(collection, values);
            if (fileUri == null) throw new IllegalStateException("Android ने Downloads फ़ाइल नहीं बनाई।");

            try {
                try (OutputStream out = getContentResolver().openOutputStream(fileUri, "w")) {
                    if (out == null) throw new IllegalStateException("Downloads फ़ाइल खुल नहीं सकी।");
                    out.write(bytes);
                    out.flush();
                }
                ContentValues published = new ContentValues();
                published.put(MediaStore.Downloads.IS_PENDING, 0);
                int updated = getContentResolver().update(fileUri, published, null, null);
                if (updated <= 0) throw new IllegalStateException("डाउनलोड प्रकाशित नहीं हो सका।");
            } catch (Exception writeError) {
                getContentResolver().delete(fileUri, null, null);
                throw writeError;
            }

            runOnUiThread(() -> Toast.makeText(MainActivity.this,
                "फाइल Downloads/Crates Ledger में सेव हो गई।", Toast.LENGTH_LONG).show());
        }

        private void showDownloadError(Exception e) {
            final String reason = e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage();
            runOnUiThread(() -> Toast.makeText(MainActivity.this,
                "फाइल सेव नहीं हो सकी: " + reason, Toast.LENGTH_LONG).show());
        }

        @JavascriptInterface
        public void printHtml(String html, String jobName) {
            if (html == null || html.trim().isEmpty()) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this,
                    "प्रिंट करने के लिए रिपोर्ट उपलब्ध नहीं है।", Toast.LENGTH_LONG).show());
                return;
            }

            runOnUiThread(() -> {
                try {
                    PrintManager printManager = (PrintManager) getSystemService(PRINT_SERVICE);
                    if (printManager == null) {
                        Toast.makeText(MainActivity.this,
                            "इस डिवाइस पर Android Print Service उपलब्ध नहीं है।",
                            Toast.LENGTH_LONG).show();
                        return;
                    }

                    WebView printWebView = new WebView(MainActivity.this);
                    activePrintWebViews.add(printWebView);
                    WebSettings printSettings = printWebView.getSettings();
                    printSettings.setJavaScriptEnabled(false);
                    printSettings.setDomStorageEnabled(false);
                    printSettings.setDefaultTextEncodingName("UTF-8");
                    // Keep print layout at its CSS page dimensions. Overview/viewport
                    // scaling can shrink the document before the print adapter lays it out.
                    printSettings.setLoadWithOverviewMode(false);
                    printSettings.setUseWideViewPort(false);
                    printSettings.setTextZoom(100);
                    printWebView.setBackgroundColor(Color.WHITE);

                    String safeJob = (jobName == null || jobName.trim().isEmpty())
                        ? "Crates Ledger" : jobName.trim();
                    safeJob = safeJob.replaceAll("[\\\\/:*?\\\"<>|]", "_");

                    final String printJobName = safeJob;
                    final boolean[] submitted = {false};
                    printWebView.setWebViewClient(new WebViewClient() {
                        @Override
                        public void onPageFinished(WebView view, String url) {
                            if (submitted[0]) return;
                            submitted[0] = true;
                            try {
                                PrintDocumentAdapter delegate =
                                    view.createPrintDocumentAdapter(printJobName);
                                PrintDocumentAdapter managedAdapter = new PrintDocumentAdapter() {
                                    @Override
                                    public void onStart() {
                                        delegate.onStart();
                                    }

                                    @Override
                                    public void onLayout(PrintAttributes oldAttributes,
                                                         PrintAttributes newAttributes,
                                                         CancellationSignal cancellationSignal,
                                                         LayoutResultCallback callback,
                                                         Bundle extras) {
                                        delegate.onLayout(oldAttributes, newAttributes,
                                            cancellationSignal, callback, extras);
                                    }

                                    @Override
                                    public void onWrite(PageRange[] pages,
                                                        ParcelFileDescriptor destination,
                                                        CancellationSignal cancellationSignal,
                                                        WriteResultCallback callback) {
                                        delegate.onWrite(pages, destination,
                                            cancellationSignal, callback);
                                    }

                                    @Override
                                    public void onFinish() {
                                        try {
                                            delegate.onFinish();
                                        } finally {
                                            releasePrintWebView(view);
                                        }
                                    }
                                };
                                printManager.print(printJobName, managedAdapter,
                                    new PrintAttributes.Builder().build());
                            } catch (Exception error) {
                                releasePrintWebView(view);
                                Toast.makeText(MainActivity.this,
                                    "PDF प्रिंट शुरू नहीं हो सका: " + error.getMessage(),
                                    Toast.LENGTH_LONG).show();
                            }
                        }
                    });

                    printWebView.loadDataWithBaseURL(
                        "file:///android_asset/", html, "text/html", "UTF-8", null);
                } catch (Exception error) {
                    Toast.makeText(MainActivity.this,
                        "PDF प्रिंट शुरू नहीं हो सका: " + error.getMessage(),
                        Toast.LENGTH_LONG).show();
                }
            });
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        if (webView != null) webView.saveState(outState);
        super.onSaveInstanceState(outState);
    }

    @Override
    protected void onDestroy() {
        if (fileChooserCallback != null) {
            fileChooserCallback.onReceiveValue(null);
            fileChooserCallback = null;
        }
        if (webView != null) {
            webView.removeJavascriptInterface("AndroidLedgerBridge");
            webView.destroy();
            webView = null;
        }
        for (WebView printView : new HashSet<>(activePrintWebViews)) {
            releasePrintWebView(printView);
        }
        activePrintWebViews.clear();
        super.onDestroy();
    }
}
