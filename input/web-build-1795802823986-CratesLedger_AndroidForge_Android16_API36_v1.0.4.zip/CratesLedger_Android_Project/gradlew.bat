@echo off
setlocal
if not defined GRADLE_USER_HOME set "GRADLE_USER_HOME=%USERPROFILE%\.gradle"
set "WRAPPER_ROOT=%GRADLE_USER_HOME%\wrapper\dists\gradle-8.13-bin\androidforge"
set "GRADLE_HOME=%WRAPPER_ROOT%\gradle-8.13"
set "ZIP_PATH=%WRAPPER_ROOT%\gradle-8.13-bin.zip"
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; $root=$env:WRAPPER_ROOT; $zip=$env:ZIP_PATH; $home=$env:GRADLE_HOME; $expected='20f1b1176237254a6fc204d8434196fa11a4cfb387567519c61556e8710aed78'; New-Item -ItemType Directory -Force -Path $root | Out-Null; if (!(Test-Path (Join-Path $home 'bin\gradle.bat'))) { if (!(Test-Path $zip)) { Invoke-WebRequest -Uri 'https://services.gradle.org/distributions/gradle-8.13-bin.zip' -OutFile $zip }; $actual=(Get-FileHash -Algorithm SHA256 -LiteralPath $zip).Hash.ToLowerInvariant(); if ($actual -ne $expected) { Remove-Item -Force $zip; throw 'Gradle 8.13 SHA-256 verification failed' }; Expand-Archive -LiteralPath $zip -DestinationPath $root -Force }"
if errorlevel 1 exit /b 1
call "%GRADLE_HOME%\bin\gradle.bat" %*
exit /b %ERRORLEVEL%
