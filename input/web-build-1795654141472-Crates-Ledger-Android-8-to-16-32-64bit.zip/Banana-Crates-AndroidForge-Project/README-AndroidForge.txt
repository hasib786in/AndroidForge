CRATES LEDGER — ANDROID PROJECT

Android OS compatibility configuration:
- Android 12 (API 31) through Android 16 (API 36)
- minSdk 31
- compileSdk 36
- targetSdk 36

CPU architecture / ABI configuration:
- armeabi-v7a: 32-bit ARM
- arm64-v8a: 64-bit ARM
- x86: 32-bit Intel (emulators / compatible devices)
- x86_64: 64-bit Intel (emulators / compatible devices)

Project contents:
- app/src/main/assets/index.html : Crates Ledger web application
- app/src/main/java/com/bananacrates/ledger/MainActivity.java : Android WebView wrapper
- app/src/main/res/mipmap-* : launcher icon images for mdpi through xxxhdpi
- app/src/main/res/mipmap-anydpi-v26/ic_launcher.xml : Android adaptive launcher icon
- App display name: Crates Ledger

Build environment:
- Android Gradle Plugin 8.9.1
- Gradle 8.11.1
- JDK 17
- Android SDK Platform 36

Build:
1. Open the project folder in Android Studio (Meerkat or newer).
2. Install Android SDK Platform 36 if prompted.
3. Sync Gradle.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).

The project ZIP contains source code and wrapper configuration. It is not a prebuilt APK.
The ABI filters configure supported target architectures; actual APK outputs must be built and tested on devices/emulators.
The HTML uses a SheetJS CDN for spreadsheet features; internet access is required for that feature.
