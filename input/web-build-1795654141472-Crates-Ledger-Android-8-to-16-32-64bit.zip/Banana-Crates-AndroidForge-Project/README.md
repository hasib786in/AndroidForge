# Crates Ledger – Android project

## Compatibility target
- Android 8.0 (API 26) through Android 16 (API 36), subject to device WebView/system requirements.
- 32-bit ARM (`armeabi-v7a`) and 64-bit ARM (`arm64-v8a`).
- 32-bit Intel (`x86`) and 64-bit Intel (`x86_64`).
- Package/application label: **Crates Ledger**.

The app uses Android WebView to display `app/src/main/assets/index.html`.
The activity uses the modern edge-to-edge/insets APIs only on Android 11+;
Android 8.0–10 use the normal system-window layout.

## Build
Open this project folder in a compatible Android Studio installation, install Android SDK Platform 36 and use JDK 17.
The project is configured with Android Gradle Plugin 8.9.1 and Gradle 8.11.1.

To build an APK from Android Studio: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

## Important validation note
This ZIP contains Android project source, not a prebuilt APK. The current execution environment does not have Android SDK/Gradle build tools, so an APK build and installation test on physical Samsung/Vivo/OPPO/Realme/Redmi/POCO devices have not been performed. Compatibility is configured for API 26–36 and the listed ABIs, but actual device validation is still required.
