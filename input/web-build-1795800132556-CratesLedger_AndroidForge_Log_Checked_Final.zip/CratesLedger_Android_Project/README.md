# Crates Ledger — AndroidForge project

This project packages the Crates Ledger HTML application inside a native Android
WebView shell. The customer-ledger HTML, local SheetJS library, native file
picker, Downloads bridge, and Android PrintManager integration are included.

## AndroidForge-compatible build configuration

- Android Gradle Plugin: **8.7.3**
- Gradle: **8.9**
- JDK: **17**
- Compile SDK: **35**
- Target SDK: **34** (retained for the established system-bar-safe layout)
- Minimum SDK: **31** (Android 12)
- ARM ABIs: `armeabi-v7a` (32-bit) and `arm64-v8a` (64-bit)
- App version: **1.0.1**, versionCode **2**

### Why these versions are pinned

The AndroidForge standalone Gradle runner shown in the user's build screen
provides Gradle 8.9 when a project has no Gradle Wrapper launcher. Its current
fallback logic can incorrectly leave Gradle 8.9 selected for projects that
request later Gradle 8.x versions. The previous package used AGP 8.13.2, whose
minimum Gradle version is 8.13; that combination therefore did not match this
runner.

This package is now pinned to AGP 8.7.3 + Gradle 8.9 + JDK 17. This is the
matching compatibility set for the AndroidForge standalone runner. Compile
SDK 35 is supported by AGP 8.7.x. Target SDK 34 is intentionally retained to
avoid forced edge-to-edge behavior associated with target 35+ on Android 15/16,
which could put the WebView header under the status bar. Minimum SDK 31 keeps
the app installable on Android 12–16.

Do not upgrade only one item in this toolchain. In particular, do not change
the AGP/Gradle pair independently while using this AndroidForge runner.

## Build

The included GitHub Actions workflow installs JDK 17, Android SDK Platform 35,
Build Tools 35.0.0, and standalone Gradle 8.9. It runs:

```bash
gradle --no-daemon clean assembleDebug
```

The workflow uploads the debug APK as `CratesLedger-Android-APK`.
Expected output path:

```text
app/build/outputs/apk/debug/app-debug.apk
```

The project contains `gradle-wrapper.properties` for IDE/version reference but
does not include `gradlew`, `gradlew.bat`, or `gradle-wrapper.jar`. The AndroidForge
website runner therefore uses the standalone Gradle 8.9 path, matching the AGP
8.7.3 requirement.

## Included Android behavior

- WebView JavaScript and DOM storage for the existing localStorage ledger
- Native Android document picker for JSON, CSV and Excel restore
- CSV parser supports comma, semicolon and tab delimiters, UTF-8 BOM,
  CRLF/LF/CR endings, escaped quotes and quoted multiline fields
- CSV restore validates records and customer links before replacing data;
  if saving fails, the previous in-memory database is restored
- JSON and CSV backup buttons save UTF-8 files to `Downloads/Crates Ledger`
  through MediaStore
- Blob-based ledger CSV/Excel exports are intercepted and saved natively
- SheetJS 0.18.5 is bundled locally at `app/src/main/assets/xlsx.full.min.js`;
  Excel import/export does not require jsDelivr or internet access
- Android PrintManager produces text/table-based print output (not screenshots)
- Native print CSS forces white page backgrounds and avoids splitting table rows
  where the print engine supports the CSS rules
- WhatsApp/SMS hand-off and Android back navigation
- Launcher icon uses the Banana Crates artwork; app label is `Crates` and
  `Ledger` on two lines

## Opening page matching

The HTML screenshot is the visual reference. The APK uses the same HTML header,
logo, title, subtitle, red divider, home cards, gradients, and page background.
The APK-only mobile control-height rules remain because the standalone WebView
has a taller viewport than mobile Chrome (Chrome's address/navigation toolbars
are absent). The previous Android-only extra header enlargement and forced
1 cm page-down offset are not applied, so the page is not artificially shifted.

The requested lower green/purple home background extension is implemented as a
separate 5 mm wider pseudo-element behind the lower Home page only; it does not
change the buttons, cards or content widths.

## Data safety

- Records remain in the app's WebView local storage.
- Clearing app storage or uninstalling the app removes local records.
- Export a JSON backup before restoring data or installing a new build.
- The configured workflow creates a debug APK, not a production-signed APK.
  A signed release requires a private signing key and secure signing setup.

## Verification status

Static checks in this package include HTML JavaScript syntax, local SheetJS
syntax and workbook round-trip, CSV parser/import round-trip, JavaScript shim
syntax, Android XML parsing, Gradle/AGP version consistency, launcher resources,
and ZIP integrity.

No Android SDK/Gradle toolchain is available in the file-generation environment.
Therefore this package has **not** been compiled into an APK here and has not
been physically tested on a Samsung/Android device. AndroidForge build and
on-device verification remain necessary.
