# Customer Ledger Android Project

यह Android Studio/Gradle source project है, जिसमें मूल `Customer-Ledger-WhatsApp-User-Format.html` को स्थानीय WebView asset के रूप में रखा गया है।

## खास बातें
- मुख्य HTML और उसकी CSS/JavaScript ऐप के भीतर है; मुख्य लेजर स्क्रीन इंटरनेट के बिना खुलनी चाहिए।
- WebView DOM storage चालू है, जिससे HTML का `localStorage` इस्तेमाल हो सके।
- JSON/CSV export के लिए Android document picker की integration का प्रारंभिक bridge दिया गया है।
- HTML का file input JSON backup import के लिए Android file chooser से जुड़ा है।
- WhatsApp/SMS links को बाहरी ऐप/ब्राउज़र में खोलने का प्रयास होता है।

## APK बनाने के लिए
यह source ZIP है, पहले से बना APK नहीं। AndroidForge की ZIP संरचना/Gradle समर्थन के अनुसार कुछ अनुकूलन की जरूरत हो सकती है। यदि AndroidForge सीधे Android Studio Gradle project ZIP नहीं स्वीकारता, तो Android Studio या संगत CI build का उपयोग करें।

Android Studio में:
1. ZIP extract करें।
2. `CustomerLedgerAndroid` project खोलें।
3. Gradle sync पूरा होने दें।
4. Build > Build APK(s) चुनें।

## सावधानी
पहले test data से ग्राहक जोड़ना, लेन-देन सेव करना, JSON backup export/import करना और offline launch जाँचें। वास्तविक ग्राहक डेटा इस्तेमाल करने से पहले backup बनाएं। APK install होने पर पुराने browser का `localStorage` अपने आप ऐप में नहीं आता।
