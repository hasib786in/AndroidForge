# Crates Ledger — AndroidForge project

This project packages the Crates Ledger HTML application inside a native Android
WebView shell. The customer-ledger HTML, local SheetJS library, native file
picker, Downloads bridge, and Android PrintManager integration are included.

## Android build configuration

- Android Gradle Plugin: **8.13.2**
- Gradle: **8.13**
- JDK: **17**
- Compile SDK: **36**
- Target SDK: **34** (deliberately retained for the established system-bar-safe layout)
- Minimum SDK: **31** (Android 12)
- ARM ABIs: `armeabi-v7a` (32-bit) and `arm64-v8a` (64-bit)
- App version: **1.0.1**, versionCode **2**

AGP 8.13 requires Gradle 8.13 and JDK 17. AGP 8.13 supports API 36.
Target SDK 34 is intentional: the app remains installable on Android 12–16,
while avoiding the target-35/36 forced edge-to-edge behavior that could place
the WebView header underneath the status bar. The system status and navigation
bars remain visible.

## Build

The included GitHub Actions workflow installs JDK 17, Android SDK Platform 36,
Build Tools 35.0.0, and standalone Gradle 8.13. It runs:

```bash
gradle --no-daemon clean assembleDebug
```

The workflow uploads the debug APK as `CratesLedger-Android-APK`.
Expected output path:

```text
app/build/outputs/apk/debug/app-debug.apk
```

The workflow uses standalone Gradle; the archive includes the matching
`gradle-wrapper.properties` for version reference but does not include
`gradlew`, `gradlew.bat`, or `gradle-wrapper.jar`. Use the supplied workflow or
an environment that provides Gradle 8.13. Do not mix AGP 8.13.2 with Gradle 8.9.

## Included Android behavior

- WebView JavaScript and DOM storage for the existing localStorage ledger
- Native Android document picker for JSON, CSV and Excel restore
- CSV parser supports comma, semicolon and tab delimiters, UTF-8 BOM,
  CRLF/LF/CR endings, escaped quotes and quoted multiline fields
- CSV restore validates records and customer links before replacing data;
  if saving fails, the previous in-memory database is restored
- JSON and CSV backup buttons save UTF-8 files to `Downloads/Crates Ledger`
  through MediaStore
- Blob-based ledger CSV/Excel exports are intercepted and saved natively
- SheetJS 0.18.5 is bundled locally at `app/src/main/assets/xlsx.full.min.js`;
  Excel import/export does not require jsDelivr or internet access
- Android PrintManager produces text/table-based print output (not screenshots)
- Native print CSS forces white page backgrounds and avoids splitting table rows
  where the print engine supports the CSS rules
- WhatsApp/SMS hand-off and Android back navigation
- Launcher icon uses the Banana Crates artwork; app label is `Crates` and
  `Ledger` on two lines

## Opening page matching

The HTML screenshot is the visual reference. The APK uses the same HTML header,
logo, title, subtitle, red divider, home cards, gradients, and page background.
The APK-only mobile control-height rules remain because the standalone WebView
has a taller viewport than mobile Chrome (Chrome's address/navigation toolbars
are absent). The previous Android-only extra header enlargement and forced
1 cm page-down offset are not applied, so the page is not artificially shifted.

The requested lower green/purple home background extension is implemented as a
separate 5 mm wider pseudo-element behind the lower Home page only; it does not
change the buttons, cards or content widths.

## Data safety

- Records remain in the app's WebView local storage.
- Clearing app storage or uninstalling the app removes local records.
- Export a JSON backup before restoring data or installing a new build.
- The configured workflow creates a debug APK, not a production-signed APK.
  A signed release requires a private signing key and secure signing setup.

## Verification status

Static checks in this package include HTML JavaScript syntax, local SheetJS
syntax and workbook round-trip, CSV parser/import round-trip, JavaScript shim
syntax, Android XML parsing, Gradle/AGP version consistency, launcher resources,
and ZIP integrity.

No Android SDK/Gradle toolchain is available in the file-generation environment.
Therefore this package has **not** been compiled into an APK here and has not
been physically tested on a Samsung/Android device. AndroidForge/GitHub build
and on-device verification remain necessary.
