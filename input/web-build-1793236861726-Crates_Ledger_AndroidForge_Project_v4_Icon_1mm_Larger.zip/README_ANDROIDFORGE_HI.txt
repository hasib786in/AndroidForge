क्रेट्स लेजर — AndroidForge APK Project ZIP
===========================================

इस ZIP में Android Gradle project है। आपकी मौजूदा क्रेट्स लेजर HTML फ़ाइल ऐप के अंदर रखी गई है और दी गई क्रेट्स वाली फोटो को launcher icon बनाया गया है।

AndroidForge पर इस्तेमाल:
1. AndroidForge वेब UI खोलें: https://professional-x.github.io/AndroidForge/
2. इस ZIP को Android project ZIP के रूप में चुनें/अपलोड करें।
3. Build variant में Auto या Debug चुनें और build चलाएँ।
4. Build पूरा होने पर workflow artifact से APK डाउनलोड करें।

Project details:
- App name: क्रेट्स लेजर
- Package ID: in.cratesledger.app
- Version: 1.0 (versionCode 1)
- Minimum Android: Android 6.0 (API 23)
- HTML local assets में है: app/src/main/assets/index.html
- Launcher icon: आपकी दी हुई क्रेट्स की फोटो से बनाया गया है।
- JavaScript और localStorage सक्षम हैं ताकि मौजूदा लेजर UI काम कर सके।
- PDF/Print के लिए Android print dialog जोड़ा गया है।
- Excel import के लिए file chooser और डाउनलोड के लिए DownloadManager जोड़ा गया है।

महत्वपूर्ण:
- यह source project ZIP है, APK नहीं। APK AndroidForge में build करने के बाद मिलेगा।
- Excel रिपोर्ट के लिए मौजूदा HTML में SheetJS CDN (jsdelivr) का इस्तेमाल है; Excel फ़ीचर चलाने के समय इंटरनेट चाहिए।
- APK पहली बार खोलने पर मौजूदा ब्राउज़र के localStorage रिकॉर्ड अपने-आप ऐप में नहीं आएँगे। पुराने रिकॉर्ड चाहिए तो HTML ऐप में उपलब्ध backup/restore विकल्प का उपयोग करें।
- इस ZIP को अभी Android emulator/physical phone पर build/run करके परीक्षण नहीं किया गया है। AndroidForge build logs में कोई त्रुटि आए तो उन्हें साझा करें।
