Customer Ledger - AndroidForge source ZIP

Contents:
- index.html: standalone HTML customer ledger app.

How to build using AndroidForge:
1. Open AndroidForge in your browser.
2. In the repository/token step, select the intended GitHub repository if needed. Do not share your GitHub token with anyone.
3. Under “Upload source ZIP”, choose this ZIP file.
4. Select Target platform: Android (APK).
5. Leave Build variant at auto (or choose debug for a test build if available).
6. Tap Build and wait for the build to finish.
7. Download the generated APK and install it on your phone. Android may ask you to allow installation from this browser/file manager.

Important:
- This ZIP contains the HTML app source, not an APK.
- Test the APK and make a JSON backup of customer/transaction data before relying on it.
- Browser localStorage data may not automatically transfer between the browser version and the installed APK.
