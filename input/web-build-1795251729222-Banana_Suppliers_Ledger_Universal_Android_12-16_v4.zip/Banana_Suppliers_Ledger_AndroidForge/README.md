# 🍌Suppliers Ledger Android project

Import this Gradle project into AndroidForge / Android Studio. See `README_ANDROIDFORGE_HI.md` for Hindi build and installation steps.


## Compatibility
Updated for Android 16 SDK (compile/target API 36), AGP 8.10.1, Gradle 8.11.1, Java 17. Minimum SDK remains API 23. See `README_ANDROIDFORGE_HI.md` for the Android 12–16 edge-to-edge, predictive-back and testing notes.


## Universal Android / OEM compatibility (v4)

यह ऐप किसी Samsung-only API या brand-specific service पर निर्भर नहीं है। यह Android Activity, Android WebView, Android Print Framework, DownloadManager और standard intents उपयोग करता है। इसलिए इसका एक ही APK Android 12–16 वाले Vivo, OPPO, Redmi/Xiaomi, realme, Motorola, OnePlus, Samsung तथा अन्य Android ब्रांडों के लिए बनाया गया है।

- `minSdk 23`, `compileSdk 36`, `targetSdk 36`; AGP 8.10.1 और Gradle 8.11.1.
- कोई ABI split/`abiFilters` नहीं; कोई `.so` native library नहीं। इस Java/WebView project के लिए एक universal APK configuration है।
- अलग-अलग OEM के status/navigation bar, display cutout और keyboard insets को संभालने के लिए edge-to-edge insets लागू किए गए हैं।
- File chooser cancel/result और PrintManager null-service स्थितियों को संभाला गया है।
- App version 1.1.0 / versionCode 2 किया गया है ताकि पहले version 1.0.0 के ऊपर update install किया जा सके।
- GitHub Actions `lintDebug` और `assembleDebug` चलाता है।

**Compatibility की सीमा:** Android संस्करण/API compatibility और OEM brand compatibility source-level पर तैयार की गई है। हर ब्रांड के हर model/ROM पर वास्तविक प्रमाणन नहीं हुआ है। OEM battery/background restrictions, default browser/WhatsApp, installed Android System WebView provider, printer service और firmware variations अलग हो सकते हैं। अंतिम पुष्टि के लिए वास्तविक फोन पर install, open, data save/reopen, file picker, download, WhatsApp, PDF print और app update का परीक्षण करें।
