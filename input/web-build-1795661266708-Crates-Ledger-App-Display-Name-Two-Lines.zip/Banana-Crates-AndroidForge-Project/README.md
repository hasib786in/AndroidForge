CRATES LEDGER — ANDROIDFORGE BUILD PROJECT

Android OS compatibility target:
- Android 8.0 (API 26) and newer, including Android 12–16
- minSdk 26
- compileSdk 35
- targetSdk 35
- 32-bit ARM: armeabi-v7a
- 64-bit ARM: arm64-v8a
- 32-bit Intel: x86
- 64-bit Intel: x86_64

Build toolchain chosen to match AndroidForge's current build image:
- Android Gradle Plugin (AGP): 8.7.3
- Gradle: 8.9
- JDK: 17
- compile SDK: 35

Why these versions:
The previous build used AGP 8.9.1, which requires Gradle 8.11.1 or newer.
The AndroidForge run log showed that its build environment actually used Gradle 8.9.
AGP 8.7.3 is selected to be compatible with that Gradle version, avoiding the
reported plugin-application failure.

Project contents:
- app/src/main/assets/index.html : Crates Ledger web application
- app/src/main/java/com/bananacrates/ledger/MainActivity.java : Android WebView wrapper
- app/src/main/res/mipmap-* : launcher icons
- App display name: Crates Ledger

Build:
Upload this ZIP to AndroidForge and run Build APK.

Important:
This is an Android source project ZIP, not a prebuilt APK. A successful APK
build and physical-device testing have not yet been performed. Android 8.0+
compatibility is configured; actual behavior may vary by device vendor,
WebView version, CPU ABI, and Android customization.

UI update: JSON backup download and restore controls are displayed side-by-side in a two-column row.


Backup/file handling update:
- Android WebView file picker support added for JSON, CSV, and Excel restore inputs.
- JSON, CSV, and XLSX exports now use Android's system Save File dialog through a JavaScript bridge.
- This avoids relying on unsupported WebView blob-download behavior.
- On Android outside the APK, normal browser download behavior remains as a fallback.


WhatsApp/SMS link handling:
- Android WebView intercepts whatsapp:// and wa.me / whatsapp.com links and opens them with ACTION_VIEW in the installed app.
- SMS, telephone, email, and geo links are also routed to an external Android app rather than loaded as web pages.
- Actual hand-off depends on WhatsApp/SMS apps being installed and registered on the device.


SMS launch update:
- SMS links are intercepted in the Android WebView and opened using ACTION_SENDTO.
- The recipient is passed as an smsto: URI and the message body as sms_body.
- The HTML SMS action uses the smsto: scheme.


Customer PDF / Print update:
- Customer ledger printing in the Android APK now uses the native Android PrintManager.
- The Android print sheet should offer available destinations such as Save as PDF or a connected printer.
- Browser fallback remains available when running the HTML outside the Android APK.

Launcher display name update: the app label is set to `Crates\nLedger` so Android launchers that honor line breaks can display it on two lines.
