Customer Ledger Android project for AndroidForge

इस ZIP में app/src/main/assets/index.html के रूप में मूल Customer-Ledger-WhatsApp-User-Format.html रखा गया है। ऐप इसे Android WebView में चलाता है। JavaScript और DOM storage सक्षम हैं; CSV/JSON export Downloads में सेव होता है; WhatsApp/SMS links बाहरी ऐप में खुलते हैं।

AndroidForge पर इस ZIP को upload करें। AndroidForge के लिए अपने GitHub खाते में AndroidForge repository का fork चाहिए और GitHub Personal Access Token की आवश्यकता हो सकती है। Token केवल आधिकारिक AndroidForge वेबसाइट पर दर्ज करें; इसे किसी व्यक्ति या चैट में साझा न करें।

Project root: settings.gradle, build.gradle, gradle.properties, app/build.gradle
Build variant: debug से शुरुआत करें।
