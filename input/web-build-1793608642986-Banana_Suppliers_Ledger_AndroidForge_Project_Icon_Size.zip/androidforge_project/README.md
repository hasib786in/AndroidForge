# Banana Suppliers Ledger — AndroidForge project

This is an Android WebView wrapper around the supplied `Banana Suppliers Ledger.html` application.

## AndroidForge

Upload this ZIP as the Android source project in AndroidForge and select **Android / Auto** (or Debug). AndroidForge should detect the Gradle project and build the `app` module.

## App configuration

- App name: Banana Suppliers Ledger
- Package: `com.bananasuppliers.ledger`
- Version: `1.0.0` (versionCode 1)
- Minimum Android: Android 6.0 (API 23)
- Compile SDK: 35; Target SDK: 34
- Java: 17; Android Gradle Plugin: 8.7.3

## Included behavior

- Original HTML/CSS/JavaScript app is bundled at `app/src/main/assets/index.html`.
- JavaScript and DOM storage are enabled so the app's existing localStorage database works inside the WebView.
- JSON/CSV/Excel Blob downloads are routed to the device Downloads folder on Android 10+ (Android 6–9: app-specific Downloads folder).
- Restore file inputs use Android's document picker.
- `window.print()` is routed to Android's native print/PDF dialog.
- SMS, telephone, WhatsApp and mail links are handed to Android apps when available.

## Notes

- The app stores ledger data locally on the device. This wrapper does not add cloud synchronization.
- The supplied HTML loads SheetJS from jsDelivr for Excel import/export. Internet access is therefore needed for Excel features unless the library is bundled locally later. Core ledger functions and browser storage are local.
- PDF printing uses Android's system print service; choose **Save as PDF** in the Android print dialog.
- This ZIP is source code, not a built APK. AndroidForge must run the Gradle build to produce the APK.


## Launcher icon
The supplied Banana Suppliers Ledger logo is included as Android launcher icons for all standard densities, with an adaptive icon for Android 8.0 and newer. The app label is “Banana Suppliers Ledger”.
