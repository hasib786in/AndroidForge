BANANA SUPPLIERS LEDGER — ANDROIDFORGE WEB PROJECT
====================================================

PROJECT CONTENTS
- index.html: the supplied Banana Suppliers Ledger application, retained as the app entry point.
- assets/icon-512.png: supplied app artwork at 512 x 512.
- assets/icon-maskable-512.png: safe-zone inset artwork for maskable launchers.
- crates_ledger_app_icon.png: icon filename referenced by the original HTML.
- manifest.webmanifest: web-app metadata and icon declarations.
- android-resources/: optional Android launcher PNG resources in standard density sizes.

ANDROIDFORGE IMPORT
1. Open AndroidForge and choose its HTML / website ZIP import option.
2. Import this ZIP file. The entry page is at the ZIP root as index.html.
3. In AndroidForge's app branding/settings screen, set the installed application name to EXACTLY:
   🍌Suppliers Ledger
4. Set the app icon to assets/icon-512.png (or the supplied maskable variant if the builder asks for one).
5. Enable JavaScript and local storage for the WebView. Allow file downloads if you want to export backups/CSV.
6. Build and test the APK on your Android phone.

IMPORTANT COMPATIBILITY NOTES
- The original app source has been retained; no ledger calculations or database logic were intentionally rewritten.
- The original HTML loads SheetJS (xlsx) from jsDelivr:
  https://cdn.jsdelivr.net/npm/xlsx@0.18.5/dist/xlsx.full.min.js
  Therefore Excel features that rely on this library require internet access unless the library is later bundled locally.
- WhatsApp and SMS actions hand off to the corresponding Android apps using their URL schemes.
- The app stores its database in browser localStorage. In an Android WebView wrapper, test data persistence after force-close/reopen and APK updates. Export regular backups before relying on it for business records.
- This is an importable HTML project ZIP, NOT a compiled APK or a complete Gradle/Android Studio project. AndroidForge generates the Android wrapper/project during its import/build workflow.

REQUESTED BRANDING
Launcher label: 🍌Suppliers Ledger
Launcher artwork: the user's supplied Banana Suppliers Ledger icon.
