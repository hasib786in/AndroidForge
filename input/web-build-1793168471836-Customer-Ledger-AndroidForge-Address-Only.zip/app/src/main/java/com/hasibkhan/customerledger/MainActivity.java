package com.hasibkhan.customerledger;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.*;
import android.content.Intent;
import android.net.Uri;
import android.widget.Toast;
import java.io.OutputStream;
import android.util.Base64;

public class MainActivity extends Activity {
 private WebView web; private ValueCallback<Uri[]> fileCallback; private static final int PICK=7, CREATE_FILE=8;
 private byte[] pendingBytes; private String pendingMime="application/octet-stream";
 @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(0xFF123B65);getWindow().setNavigationBarColor(0xFF123B65);
 web=new WebView(this);setContentView(web);WebSettings s=web.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);s.setDatabaseEnabled(true);s.setAllowFileAccess(true);s.setAllowContentAccess(true);
 web.setWebViewClient(new WebViewClient());web.setWebChromeClient(new WebChromeClient(){
 @Override public boolean onShowFileChooser(WebView v,ValueCallback<Uri[]> cb,FileChooserParams p){if(fileCallback!=null)fileCallback.onReceiveValue(null);fileCallback=cb;try{startActivityForResult(p.createIntent(),PICK);return true;}catch(Exception e){fileCallback=null;return false;}}
 });
 web.addJavascriptInterface(new Object(){@JavascriptInterface public void saveFile(String name,String mime,String base64){
   try { pendingBytes=Base64.decode(base64,Base64.DEFAULT); pendingMime=mime;
     runOnUiThread(()->{Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType(mime==null||mime.isEmpty()?"application/octet-stream":mime);i.putExtra(Intent.EXTRA_TITLE,name==null?"backup.json":name);startActivityForResult(i,CREATE_FILE);});
   } catch(Exception e){runOnUiThread(()->Toast.makeText(MainActivity.this,"फ़ाइल तैयार नहीं हो सकी",Toast.LENGTH_LONG).show());}
 }}, "AndroidBridge");
 web.loadUrl("file:///android_asset/index.html");}
 @Override protected void onActivityResult(int r,int c,Intent d){super.onActivityResult(r,c,d);
 if(r==PICK&&fileCallback!=null){fileCallback.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(c,d));fileCallback=null;}
 if(r==CREATE_FILE){if(c==RESULT_OK&&d!=null&&d.getData()!=null&&pendingBytes!=null){try(OutputStream out=getContentResolver().openOutputStream(d.getData())){out.write(pendingBytes);Toast.makeText(this,"बैकअप/फ़ाइल सफलतापूर्वक सेव हुई",Toast.LENGTH_LONG).show();}catch(Exception e){Toast.makeText(this,"फ़ाइल सेव नहीं हुई: "+e.getMessage(),Toast.LENGTH_LONG).show();}}else{Toast.makeText(this,"फ़ाइल सेव करना रद्द हुआ",Toast.LENGTH_SHORT).show();}pendingBytes=null;}
 }
 @Override public void onBackPressed(){if(web!=null&&web.canGoBack())web.goBack();else super.onBackPressed();}
 @Override protected void onDestroy(){if(web!=null)web.destroy();super.onDestroy();}
}
