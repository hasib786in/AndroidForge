@echo off
setlocal
set "APP_HOME=%~dp0"
if exist "%APP_HOME%gradle\wrapper\gradle-wrapper.jar" (
  java -classpath "%APP_HOME%gradle\wrapper\gradle-wrapper.jar" org.gradle.wrapper.GradleWrapperMain %*
  exit /b %ERRORLEVEL%
)
where gradle >nul 2>nul
if errorlevel 1 (
  echo Gradle Wrapper JAR is missing and Gradle is not installed.
  echo Run the included GitHub Actions workflow or install Gradle 8.11.1.
  exit /b 1
)
gradle --version | findstr /C:"Gradle 8.11.1" >nul
if errorlevel 1 (
  echo Standalone Gradle 8.11.1 is required.
  exit /b 1
)
gradle %*
exit /b %ERRORLEVEL%
