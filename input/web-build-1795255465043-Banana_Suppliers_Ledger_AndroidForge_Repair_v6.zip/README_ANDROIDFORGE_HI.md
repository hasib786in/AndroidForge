# 🍌Suppliers Ledger — AndroidForge Project (Repair v6)

यह ZIP एक पूर्ण Android Gradle project है। ZIP खोलने पर `settings.gradle`, `build.gradle`, `app/` और `.github/` सीधे project root में मिलेंगे। इसे AndroidForge में project ZIP के रूप में import करें या GitHub repository के root में upload करें।

## App identity and included features
- Launcher label: **🍌Suppliers Ledger**
- Original supplied launcher artwork and Android launcher density/adaptive icon resources retained.
- Existing ledger HTML retained at `app/src/main/assets/index.html`.
- Android WebView shell with JavaScript and DOM storage enabled.
- Android bridge for WhatsApp link opening and Android Print Framework.
- File picker support for HTML file inputs; DownloadManager integration for downloads.
- Android 12–16 target configuration; generic Android APIs, not Samsung-only APIs.

## Fixed build configuration
- Android Gradle Plugin: `8.10.1`
- Gradle: `8.11.1`
- Java: `17`
- compileSdk / targetSdk: `36`
- minSdk: `23`
- Application ID: `com.bananasuppliers.ledger`
- versionCode / versionName: `2` / `1.1.0`
- No ABI filters or bundled `.so` native libraries; APK is not split by CPU architecture.

## Build using AndroidForge
1. Import this ZIP, selecting the project root (the folder containing `settings.gradle`).
2. Select Java 17 and Gradle 8.11.1 if AndroidForge exposes toolchain settings.
3. Build the `:app:assembleDebug` task.
4. Download the generated APK from the build artifacts.

## Build using GitHub Actions
1. Upload the *contents* of this ZIP to the root of a GitHub repository (do not add another enclosing folder).
2. Open **Actions → Build Banana Suppliers Ledger APK → Run workflow**.
3. On success, download `Banana-Suppliers-Ledger-debug-apk` from the run's Artifacts section.
4. If it fails, download `Banana-Suppliers-Ledger-build-diagnostics` and share it for diagnosis.

## Important technical note
The wrapper properties pin Gradle 8.11.1. The binary `gradle-wrapper.jar` is intentionally not fabricated or copied from an unverified source. The included `gradlew` launchers use an existing official wrapper JAR if present; otherwise they require standalone Gradle 8.11.1. The GitHub Actions workflow provisions that exact Gradle version and invokes it directly, so it does not depend on the missing wrapper JAR.

## Compatibility and QA limits
The source uses standard Android APIs and does not bundle native `.so` libraries. This supports one universal APK configuration across 32-bit/64-bit Android environments where the device's Android System WebView and required OS services are available. However, this package has **not** been built in a full Android SDK environment here, and no physical-device certification has been performed. Android 12–16 and Samsung/Vivo/OPPO/Redmi/realme compatibility must be confirmed by a successful CI APK build and device tests (install, data persistence, file import/export, WhatsApp/SMS, downloads and PDF printing).

## Before updating the installed app
Export a JSON backup from the ledger's Backup feature. Clearing app data or uninstalling the app may remove locally stored ledger records.
