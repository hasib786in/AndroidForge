# Banana Suppliers Ledger AndroidForge project

See `README_ANDROIDFORGE_HI.md` for Hindi setup and compatibility notes. Import the folder containing `settings.gradle` as the project root. CI provisions Java 17, Gradle 8.11.1 and Android SDK 36, then builds `:app:assembleDebug`.
