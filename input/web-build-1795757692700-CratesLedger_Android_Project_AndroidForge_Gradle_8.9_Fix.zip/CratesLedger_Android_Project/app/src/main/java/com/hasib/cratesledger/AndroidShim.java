package com.hasib.cratesledger;

final class AndroidShim {
    private AndroidShim() {}
    static final String SCRIPT =
        "(function(){'use strict';" +
        "if(window.__cratesAndroidShimInstalled)return;window.__cratesAndroidShimInstalled=true;" +
        "var originalCreate=URL.createObjectURL.bind(URL), blobs={};" +
        "URL.createObjectURL=function(blob){var u=originalCreate(blob);blobs[u]=blob;return u;};" +
        "document.addEventListener('click',function(ev){" +
        "var a=ev.target&&ev.target.closest?ev.target.closest('a[download]'):null;" +
        "if(!a||!a.href||!a.href.startsWith('blob:')||!blobs[a.href])return;" +
        "ev.preventDefault();ev.stopImmediatePropagation();" +
        "var blob=blobs[a.href],reader=new FileReader();" +
        "reader.onload=function(){try{AndroidLedgerBridge.saveBase64File(a.download||'CratesLedger-export',reader.result);}catch(e){alert('फाइल सेव नहीं हो सकी।');}};" +
        "reader.onerror=function(){alert('फाइल तैयार नहीं हो सकी।');};reader.readAsDataURL(blob);" +
        "},true);" +
        "window.print=function(){try{AndroidLedgerBridge.printHtml(document.documentElement.outerHTML,document.title||'Crates Ledger');}catch(e){console.error(e);}};" +
        "})();";
}
