# Crates Ledger — Android project

This project wraps the supplied Crates Ledger HTML application in a native Android WebView shell.

## Compatibility target

- Android 12–16 (minSdk 31, targetSdk 36, compileSdk 36)
- ARM 32-bit: `armeabi-v7a`
- ARM 64-bit: `arm64-v8a`
- JDK 17
- Android Gradle Plugin 8.13.2
- Gradle 8.13

The Android Gradle Plugin 8.13 line requires Gradle 8.13 and JDK 17. The previous Gradle 8.9 workflow was not a safe choice for newer AGP 8.9+ projects.

## Build

Open this folder in a current Android Studio with Android SDK Platform 36 installed and select Gradle 8.13, or use the included GitHub Actions workflow (`.github/workflows/build-apk.yml`). The workflow installs the Android SDK components and Gradle 8.13 explicitly.

The workflow runs:

```bash
gradle --no-daemon clean assembleDebug
```

APK output:
`app/build/outputs/apk/debug/app-debug.apk`

## Included Android integrations

- Persistent WebView DOM storage for the existing `localStorage` ledger database
- File picker for JSON, CSV and Excel restore inputs
- Native save-to-Downloads handling for JSON/CSV/Excel Blob exports
- Native Android print dialog for ledger print/PDF flows
- External hand-off for WhatsApp and SMS links
- Android system back navigation

## Important

- The original HTML file is included unchanged at `app/src/main/assets/index.html`.
- This is an unsigned debug build configuration. A signed release APK/AAB requires a private signing key and credentials; do not put signing secrets in source control.
- Android app data is normally retained across app updates, but uninstalling the app or clearing its storage removes local WebView data. Export a JSON backup regularly.
- The source file's existing ledger calculations and business logic have not been modified as part of this Android packaging setup.
